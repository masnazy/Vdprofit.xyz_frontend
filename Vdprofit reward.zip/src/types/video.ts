
export interface Video {
  id: number;
  title: string;
  thumbnail: string;
  duration: string;
  reward: number;
  code: string;
  videoUrl: string;
}
