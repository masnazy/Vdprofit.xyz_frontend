
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";
import { Link } from "react-router-dom";

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // For demo purposes, we'll use hardcoded credentials
    // In a real app, this would validate against a backend API
    setTimeout(() => {
      if (email === "admin@example.com" && password === "admin123") {
        // Admin login
        const adminUser = {
          name: "John Admin",
          email: "admin@example.com",
          wallet: 1000,
          referralCode: "ADMIN123",
          tasksCompleted: 50,
          totalWithdrawal: 500,
          totalDeposit: 1500,
          isPremium: true,
          premiumBalance: 800,
          pendingDeposits: 2,
          pendingWithdrawals: 3,
          isAdmin: true,
          cryptoWallets: {
            bitcoin: 0.05,
            ethereum: 0.75,
            solana: 10,
            avax: 5,
            ada: 100,
          }
        };
        
        localStorage.setItem("user", JSON.stringify(adminUser));
        
        toast({
          title: "Login successful",
          description: "Welcome back, Admin!"
        });
        
        navigate("/admin/dashboard");
      } else if (email === "user@example.com" && password === "user123") {
        // Regular user login
        const regularUser = {
          name: "Jane User",
          email: "user@example.com",
          wallet: 125.50,
          referralCode: "USER456",
          referredBy: "ADMIN123",
          tasksCompleted: 12,
          totalWithdrawal: 50,
          totalDeposit: 200,
          isPremium: false,
          premiumBalance: 0,
          pendingDeposits: 1,
          pendingWithdrawals: 1,
          cryptoWallets: {
            bitcoin: 0.001,
            ethereum: 0.01,
            solana: 1,
            avax: 0.5,
            ada: 10,
          }
        };
        
        localStorage.setItem("user", JSON.stringify(regularUser));
        
        toast({
          title: "Login successful",
          description: "Welcome back, Jane!"
        });
        
        navigate("/dashboard");
      } else {
        toast({
          title: "Login failed",
          description: "Invalid email or password",
          variant: "destructive"
        });
      }
      
      setIsLoading(false);
    }, 1000);
  };

  return (
    <div className="flex min-h-screen bg-gradient-to-b from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950 items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        <div className="text-center">
          <img 
            src="/logo.svg" 
            alt="Logo" 
            className="h-12 mx-auto"
            onError={(e) => {
              (e.target as HTMLImageElement).src = "/placeholder.svg";
            }}
          />
          <h1 className="mt-4 text-3xl font-bold text-gray-900 dark:text-gray-100">Welcome back</h1>
          <p className="mt-1 text-gray-500 dark:text-gray-400">Sign in to your account</p>
        </div>
        
        <Card>
          <form onSubmit={handleSubmit}>
            <CardHeader>
              <CardTitle>Sign In</CardTitle>
              <CardDescription>
                Enter your credentials below to access your account
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input 
                  id="email" 
                  type="email" 
                  placeholder="Email address"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password">Password</Label>
                  <Link to="/forgot-password" className="text-sm text-blue-600 hover:text-blue-500 dark:text-blue-400">
                    Forgot password?
                  </Link>
                </div>
                <Input 
                  id="password" 
                  type="password" 
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>

              <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-md">
                <p className="text-sm font-medium text-blue-800 dark:text-blue-200">Demo Accounts</p>
                <div className="mt-1 text-xs text-blue-700 dark:text-blue-300">
                  <p><strong>Admin:</strong> admin@example.com / admin123</p>
                  <p><strong>User:</strong> user@example.com / user123</p>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col space-y-4">
              <Button className="w-full" type="submit" disabled={isLoading}>
                {isLoading ? "Signing in..." : "Sign In"}
              </Button>
              <div className="text-center text-sm text-gray-500 dark:text-gray-400">
                Don't have an account? {" "}
                <Link to="/register" className="text-blue-600 hover:text-blue-500 dark:text-blue-400">
                  Sign up
                </Link>
              </div>
            </CardFooter>
          </form>
        </Card>
      </div>
    </div>
  );
}
