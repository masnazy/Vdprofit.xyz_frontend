
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "@/hooks/use-toast";
import { EarningsSummary } from "@/components/EarningsSummary";
import { UserLayout } from "@/components/layouts/UserLayout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export type UserType = {
  name: string;
  email: string;
  phone?: string;
  wallet: number;
  referralCode: string;
  referredBy?: string;
  tasksCompleted: number;
  totalWithdrawal: number;
  totalDeposit: number;
  isPremium: boolean;
  premiumBalance: number;
  pendingDeposits?: number;
  pendingWithdrawals?: number;
  profilePicture?: string;
  kycStatus?: "not_submitted" | "pending" | "approved" | "rejected";
  kycSubmittedAt?: string;
  cryptoWallets: {
    bitcoin: number;
    ethereum: number;
    solana: number;
    avax: number;
    ada: number;
  };
};

const Dashboard = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState<UserType | null>(null);
  
  useEffect(() => {
    // Get user from localStorage (in a real app, this would be an API call)
    const storedUser = localStorage.getItem("user");
    
    if (!storedUser) {
      toast({
        title: "Authentication required",
        description: "Please login to access the dashboard",
        variant: "destructive",
      });
      navigate("/login");
      return;
    }
    
    try {
      const userData = JSON.parse(storedUser);
      // Add default values for new properties if they don't exist
      const updatedUser = {
        ...userData,
        tasksCompleted: userData.tasksCompleted || 0,
        totalWithdrawal: userData.totalWithdrawal || 0,
        totalDeposit: userData.totalDeposit || 0,
        isPremium: userData.isPremium || false,
        premiumBalance: userData.premiumBalance || 0,
        pendingDeposits: userData.pendingDeposits || 0,
        pendingWithdrawals: userData.pendingWithdrawals || 0,
        profilePicture: userData.profilePicture || null,
        kycStatus: userData.kycStatus || "not_submitted",
        cryptoWallets: userData.cryptoWallets || {
          bitcoin: 0,
          ethereum: 0,
          solana: 0,
          avax: 0,
          ada: 0,
        }
      };
      setUser(updatedUser);
      // Update the localStorage with new fields if needed
      localStorage.setItem("user", JSON.stringify(updatedUser));
    } catch (error) {
      console.error("Error parsing user data:", error);
      localStorage.removeItem("user");
      navigate("/login");
    }
  }, [navigate]);

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-b from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950">
        <div className="animate-pulse flex flex-col items-center p-8 rounded-lg bg-white dark:bg-gray-800 shadow-lg">
          <div className="w-12 h-12 mb-4 rounded-full bg-blue-200 dark:bg-blue-700"></div>
          <div className="h-4 w-24 bg-blue-200 dark:bg-blue-700 rounded mb-3"></div>
          <div className="h-3 w-32 bg-gray-200 dark:bg-gray-700 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <UserLayout user={user}>
      <main className="flex-1 container py-8">
        <EarningsSummary user={user} />
        
        <div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-100 p-6 dark:from-blue-950/50 dark:to-indigo-950/50 dark:border-blue-900">
            <h3 className="font-semibold text-lg text-blue-800 dark:text-blue-300 mb-2">Videos</h3>
            <p className="text-sm text-blue-700 dark:text-blue-400 mb-6">Watch videos and earn rewards</p>
            <Button 
              className="w-full bg-blue-600 hover:bg-blue-700"
              onClick={() => navigate('/dashboard/videos')}
            >
              View Videos
            </Button>
          </Card>
          
          <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-purple-100 p-6 dark:from-purple-950/50 dark:to-pink-950/50 dark:border-purple-900">
            <h3 className="font-semibold text-lg text-purple-800 dark:text-purple-300 mb-2">News</h3>
            <p className="text-sm text-purple-700 dark:text-purple-400 mb-6">Stay updated and earn rewards</p>
            <Button 
              className="w-full bg-purple-600 hover:bg-purple-700"
              onClick={() => navigate('/dashboard/news')}
            >
              Read News
            </Button>
          </Card>
          
          <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-100 p-6 dark:from-green-950/50 dark:to-emerald-950/50 dark:border-green-900">
            <h3 className="font-semibold text-lg text-green-800 dark:text-green-300 mb-2">Referrals</h3>
            <p className="text-sm text-green-700 dark:text-green-400 mb-6">Invite friends and earn together</p>
            <Button 
              className="w-full bg-green-600 hover:bg-green-700"
              onClick={() => navigate('/dashboard/referrals')}
            >
              Manage Referrals
            </Button>
          </Card>
        </div>
      </main>
    </UserLayout>
  );
};

export default Dashboard;
