
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "@/hooks/use-toast";
import { UserNav } from "@/components/UserNav";
import { AdminVideoManager } from "@/components/AdminVideoManager";
import { AdminNewsManager } from "@/components/AdminNewsManager";
import { AdminUsersList } from "@/components/AdminUsersList";

type AdminType = {
  name: string;
  email: string;
  isAdmin: boolean;
};

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [admin, setAdmin] = useState<AdminType | null>(null);
  
  useEffect(() => {
    // Get user from localStorage (in a real app, this would be an API call with admin validation)
    const storedUser = localStorage.getItem("user");
    
    if (!storedUser) {
      toast({
        title: "Authentication required",
        description: "Please login to access the admin dashboard",
        variant: "destructive",
      });
      navigate("/login");
      return;
    }
    
    try {
      const userData = JSON.parse(storedUser);
      
      // Check if user is admin
      if (!userData.isAdmin) {
        toast({
          title: "Access denied",
          description: "You don't have permission to access this page",
          variant: "destructive",
        });
        navigate("/dashboard");
        return;
      }
      
      setAdmin(userData);
    } catch (error) {
      console.error("Error parsing user data:", error);
      localStorage.removeItem("user");
      navigate("/login");
    }
  }, [navigate]);

  if (!admin) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>;
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-30 border-b bg-background">
        <div className="container flex h-16 items-center justify-between py-4">
          <h1 className="text-xl font-bold">Admin Dashboard</h1>
          <UserNav user={admin} />
        </div>
      </header>
      <main className="flex-1 container py-6">
        <div className="grid gap-6 md:grid-cols-3 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Total Users</CardTitle>
              <CardDescription>Platform user count</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">284</div>
              <p className="text-xs text-muted-foreground mt-1">
                +12 in the last 24 hours
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Rewards Distributed</CardTitle>
              <CardDescription>Total earnings paid out</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">$7,492.30</div>
              <p className="text-xs text-muted-foreground mt-1">
                +$320.50 this week
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>System Status</CardTitle>
              <CardDescription>Platform health and activity</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-500">Online</div>
              <p className="text-xs text-muted-foreground mt-1">
                All systems operational
              </p>
            </CardContent>
          </Card>
        </div>
        
        <Tabs defaultValue="videos" className="space-y-4">
          <TabsList>
            <TabsTrigger value="videos">Manage Videos</TabsTrigger>
            <TabsTrigger value="news">Manage News</TabsTrigger>
            <TabsTrigger value="users">Manage Users</TabsTrigger>
          </TabsList>
          <TabsContent value="videos">
            <AdminVideoManager />
          </TabsContent>
          <TabsContent value="news">
            <AdminNewsManager />
          </TabsContent>
          <TabsContent value="users">
            <AdminUsersList />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default AdminDashboard;
