
import { Link } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export default function Leaderboard() {
  // Mock leaderboard data
  const users = [
    { rank: 1, name: "John Admin", earnings: 5280.50, tasks: 125, referrals: 32 },
    { rank: 2, name: "Alice Cooper", earnings: 4325.75, tasks: 108, referrals: 27 },
    { rank: 3, name: "Robert Johnson", earnings: 3950.20, tasks: 102, referrals: 21 },
    { rank: 4, name: "Emma Davis", earnings: 3600.40, tasks: 95, referrals: 18 },
    { rank: 5, name: "Michael Brown", earnings: 3250.80, tasks: 89, referrals: 15 },
    { rank: 6, name: "Sarah Wilson", earnings: 2900.10, tasks: 80, referrals: 12 },
    { rank: 7, name: "David Taylor", earnings: 2650.30, tasks: 75, referrals: 9 },
    { rank: 8, name: "Jennifer Moore", earnings: 2400.60, tasks: 68, referrals: 8 },
    { rank: 9, name: "Jane User", earnings: 2250.25, tasks: 60, referrals: 5 },
    { rank: 10, name: "Thomas Harris", earnings: 2100.15, tasks: 55, referrals: 2 }
  ];
  
  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase();
  };
  
  const getRankColor = (rank: number) => {
    switch(rank) {
      case 1: return "bg-yellow-100 text-yellow-800 border-yellow-300";
      case 2: return "bg-gray-100 text-gray-800 border-gray-300";
      case 3: return "bg-amber-100 text-amber-800 border-amber-300";
      default: return "bg-blue-50 text-blue-800 border-blue-200";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950">
      <header className="bg-white dark:bg-gray-900 shadow-sm">
        <div className="container mx-auto px-4 py-6">
          <Link to="/" className="flex items-center">
            <img 
              src="/logo.svg" 
              alt="Logo" 
              className="h-8 w-auto mr-2"
              onError={(e) => {
                (e.target as HTMLImageElement).src = "/placeholder.svg";
              }}
            />
            <h1 className="text-xl font-bold text-gray-900 dark:text-white">Rewards Platform</h1>
          </Link>
        </div>
      </header>
      
      <main className="container mx-auto px-4 py-10">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold mb-6 text-center">Top Earners Leaderboard</h1>
          <p className="text-center mb-8 text-gray-600 dark:text-gray-300">
            Our top performers who have earned the most rewards on the platform
          </p>
          
          <Card className="mb-8">
            <CardHeader className="pb-4">
              <CardTitle>Monthly Standings</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4">
                {users.slice(0, 3).map((user) => (
                  <Card key={user.rank} className={`border-2 ${getRankColor(user.rank)}`}>
                    <CardContent className="p-6 text-center">
                      <div className="flex justify-center mb-4">
                        <Avatar className="h-20 w-20">
                          <AvatarImage src="" />
                          <AvatarFallback className="text-lg">{getInitials(user.name)}</AvatarFallback>
                        </Avatar>
                      </div>
                      <div className={`rounded-full w-8 h-8 flex items-center justify-center mx-auto mb-2 ${getRankColor(user.rank)}`}>
                        {user.rank}
                      </div>
                      <h3 className="font-medium text-lg">{user.name}</h3>
                      <p className="text-2xl font-bold text-green-600 dark:text-green-400 my-2">
                        ${user.earnings.toFixed(2)}
                      </p>
                      <div className="text-sm text-gray-600 dark:text-gray-300">
                        <p>{user.tasks} tasks completed</p>
                        <p>{user.referrals} referrals</p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
              
              <div className="mt-8">
                <div className="bg-white dark:bg-gray-800 rounded-md overflow-hidden">
                  <div className="grid grid-cols-12 gap-2 p-4 font-medium text-gray-600 dark:text-gray-300 border-b">
                    <div className="col-span-1">Rank</div>
                    <div className="col-span-4">User</div>
                    <div className="col-span-3 text-right">Earnings</div>
                    <div className="col-span-2 text-right">Tasks</div>
                    <div className="col-span-2 text-right">Referrals</div>
                  </div>
                  
                  {users.map((user) => (
                    <div 
                      key={user.rank} 
                      className="grid grid-cols-12 gap-2 p-4 border-b hover:bg-gray-50 dark:hover:bg-gray-700/50"
                    >
                      <div className="col-span-1">
                        <span className={`inline-block w-8 h-8 rounded-full text-center leading-8 ${getRankColor(user.rank)}`}>
                          {user.rank}
                        </span>
                      </div>
                      <div className="col-span-4 flex items-center">
                        <Avatar className="h-8 w-8 mr-2">
                          <AvatarImage src="" />
                          <AvatarFallback>{getInitials(user.name)}</AvatarFallback>
                        </Avatar>
                        <span>{user.name}</span>
                      </div>
                      <div className="col-span-3 text-right text-green-600 dark:text-green-400 font-medium">
                        ${user.earnings.toFixed(2)}
                      </div>
                      <div className="col-span-2 text-right">{user.tasks}</div>
                      <div className="col-span-2 text-right">{user.referrals}</div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
          
          <div className="text-center">
            <Button asChild>
              <Link to="/dashboard">Go to Dashboard</Link>
            </Button>
          </div>
        </div>
      </main>
      
      <footer className="bg-white dark:bg-gray-900 mt-10 py-8 border-t border-gray-200 dark:border-gray-800">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap justify-center md:justify-between items-center">
            <div className="w-full md:w-auto mb-4 md:mb-0 text-center md:text-left">
              <p className="text-sm text-gray-500 dark:text-gray-400">
                © 2025 Rewards Platform. All rights reserved.
              </p>
            </div>
            <div className="flex flex-wrap justify-center gap-4">
              <Link to="/about" className="text-sm text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400">
                About Us
              </Link>
              <Link to="/contact" className="text-sm text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400">
                Contact Us
              </Link>
              <Link to="/privacy" className="text-sm text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400">
                Privacy Policy
              </Link>
              <Link to="/terms" className="text-sm text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400">
                Terms & Conditions
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
