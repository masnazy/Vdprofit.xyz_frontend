
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

export default function About() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950">
      <header className="bg-white dark:bg-gray-900 shadow-sm">
        <div className="container mx-auto px-4 py-6">
          <Link to="/" className="flex items-center">
            <img 
              src="/logo.svg" 
              alt="Logo" 
              className="h-8 w-auto mr-2"
              onError={(e) => {
                (e.target as HTMLImageElement).src = "/placeholder.svg";
              }} 
            />
            <h1 className="text-xl font-bold text-gray-900 dark:text-white">Rewards Platform</h1>
          </Link>
        </div>
      </header>
      
      <main className="container mx-auto px-4 py-10">
        <div className="prose prose-blue max-w-4xl mx-auto dark:prose-invert">
          <h1 className="text-3xl font-bold mb-6">About Us</h1>
          
          <p className="text-lg mb-6">
            Welcome to our Rewards Platform, where earning rewards is as simple as watching videos, reading news, and referring friends.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">Our Mission</h2>
          <p>
            We aim to create a seamless ecosystem where users can earn rewards for their engagement and convert those rewards into various cryptocurrencies. Our platform is built on the principles of transparency, security, and user satisfaction.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">How It Works</h2>
          <p>
            Our platform rewards users for completing simple tasks like watching informative videos and reading news articles. Each completed task earns you rewards that can be withdrawn or converted to various cryptocurrencies.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">Our Team</h2>
          <p>
            Our team consists of experts in blockchain technology, user experience design, and digital marketing. We are committed to providing the best possible experience for our users and continuously improving our platform.
          </p>
          
          <div className="mt-10 flex justify-center">
            <Button asChild size="lg">
              <Link to="/register">Join Our Platform Today</Link>
            </Button>
          </div>
        </div>
      </main>
      
      <footer className="bg-white dark:bg-gray-900 mt-10 py-8 border-t border-gray-200 dark:border-gray-800">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap justify-center md:justify-between items-center">
            <div className="w-full md:w-auto mb-4 md:mb-0 text-center md:text-left">
              <p className="text-sm text-gray-500 dark:text-gray-400">
                © 2025 Rewards Platform. All rights reserved.
              </p>
            </div>
            <div className="flex flex-wrap justify-center gap-4">
              <Link to="/about" className="text-sm text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400">
                About Us
              </Link>
              <Link to="/contact" className="text-sm text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400">
                Contact Us
              </Link>
              <Link to="/privacy" className="text-sm text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400">
                Privacy Policy
              </Link>
              <Link to="/terms" className="text-sm text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400">
                Terms & Conditions
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
