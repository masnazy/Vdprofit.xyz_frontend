
import { useState, useEffect } from "react";
import { toast } from "@/hooks/use-toast";
import { UserLayout } from "@/components/layouts/UserLayout";
import { useNavigate } from "react-router-dom";
import { UserType } from "../Dashboard";
import { EarningsSummary } from "@/components/EarningsSummary";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";

// Mock leaderboard data
const MOCK_LEADERS = [
  {
    id: 1,
    name: "Alex Johnson",
    profilePicture: null,
    earnings: 1250.75,
    tasksCompleted: 152,
    rank: 1,
    isPremium: true
  },
  {
    id: 2,
    name: "Sarah Williams",
    profilePicture: null,
    earnings: 985.25,
    tasksCompleted: 123,
    rank: 2,
    isPremium: true
  },
  {
    id: 3,
    name: "Michael Brown",
    profilePicture: null,
    earnings: 782.50,
    tasksCompleted: 98,
    rank: 3,
    isPremium: false
  },
  {
    id: 4,
    name: "Emily Davis",
    profilePicture: null,
    earnings: 645.80,
    tasksCompleted: 87,
    rank: 4,
    isPremium: false
  },
  {
    id: 5,
    name: "David Wilson",
    profilePicture: null,
    earnings: 520.40,
    tasksCompleted: 72,
    rank: 5,
    isPremium: true
  },
  {
    id: 6,
    name: "Jessica Martinez",
    profilePicture: null,
    earnings: 475.90,
    tasksCompleted: 68,
    rank: 6,
    isPremium: false
  },
  {
    id: 7,
    name: "Robert Taylor",
    profilePicture: null,
    earnings: 432.15,
    tasksCompleted: 61,
    rank: 7,
    isPremium: false
  },
  {
    id: 8,
    name: "Amanda Anderson",
    profilePicture: null,
    earnings: 387.60,
    tasksCompleted: 54,
    rank: 8,
    isPremium: true
  },
  {
    id: 9,
    name: "Thomas Wilson",
    profilePicture: null,
    earnings: 342.25,
    tasksCompleted: 49,
    rank: 9,
    isPremium: false
  },
  {
    id: 10,
    name: "Rachel Moore",
    profilePicture: null,
    earnings: 298.70,
    tasksCompleted: 41,
    rank: 10,
    isPremium: false
  }
];

const Leaderboard = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState<UserType | null>(null);
  
  useEffect(() => {
    // Load user data
    const storedUser = localStorage.getItem("user");
    if (!storedUser) {
      toast({
        title: "Authentication required",
        description: "Please login to access the dashboard",
        variant: "destructive",
      });
      navigate("/login");
      return;
    }
    
    try {
      const userData = JSON.parse(storedUser);
      setUser(userData);
    } catch (error) {
      console.error("Error parsing user data:", error);
      navigate("/login");
    }
  }, [navigate]);

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-b from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950">
        <div className="animate-pulse flex flex-col items-center p-8 rounded-lg bg-white dark:bg-gray-800 shadow-lg">
          <div className="w-12 h-12 mb-4 rounded-full bg-blue-200 dark:bg-blue-700"></div>
          <div className="h-4 w-24 bg-blue-200 dark:bg-blue-700 rounded mb-3"></div>
          <div className="h-3 w-32 bg-gray-200 dark:bg-gray-700 rounded"></div>
        </div>
      </div>
    );
  }

  // Find user's position
  const userPosition = MOCK_LEADERS.findIndex(leader => leader.name === user.name);
  const userRank = userPosition !== -1 ? userPosition + 1 : 'Not ranked';

  return (
    <UserLayout user={user}>
      <main className="flex-1 container py-8">
        <EarningsSummary user={user} />
        
        <div className="mt-6">
          <Card className="bg-white dark:bg-gray-800 rounded-lg shadow-md animate-fade-in">
            <CardHeader>
              <CardTitle className="flex justify-between items-center">
                <span>Leaderboard</span>
                <Badge variant="outline" className="font-normal">
                  Your Rank: {userRank}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-16">Rank</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Tasks</TableHead>
                    <TableHead className="text-right">Earnings</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {MOCK_LEADERS.map((leader) => (
                    <TableRow 
                      key={leader.id} 
                      className={leader.name === user.name ? "bg-blue-50 dark:bg-blue-950/30" : ""}
                    >
                      <TableCell className="font-medium text-center">
                        {leader.rank <= 3 ? (
                          <span className={`inline-flex items-center justify-center w-8 h-8 rounded-full 
                            ${leader.rank === 1 ? 'bg-amber-100 text-amber-800 dark:bg-amber-800 dark:text-amber-100' :
                              leader.rank === 2 ? 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-100' :
                              'bg-orange-100 text-orange-800 dark:bg-orange-800 dark:text-orange-100'}`
                          }>
                            {leader.rank}
                          </span>
                        ) : (
                          leader.rank
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <Avatar className="h-8 w-8 mr-2">
                            <AvatarImage src={leader.profilePicture || ""} />
                            <AvatarFallback className="text-xs">
                              {leader.name.split(" ").map((n) => n[0]).join("").toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex items-center">
                            {leader.name}
                            {leader.isPremium && (
                              <span className="ml-2 inline-flex items-center justify-center px-1.5 py-0.5 text-xs rounded-full bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200">
                                Premium
                              </span>
                            )}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{leader.tasksCompleted}</TableCell>
                      <TableCell className="text-right">${leader.earnings.toFixed(2)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      </main>
    </UserLayout>
  );
};

export default Leaderboard;
