
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const AdminEmails = () => {
  return (
    <div className="container py-6">
      <h1 className="text-3xl font-bold mb-6">Email Services</h1>
      
      <Card>
        <CardHeader>
          <CardTitle>Send Message</CardTitle>
        </CardHeader>
        <CardContent>
          <form className="space-y-4">
            <div>
              <label className="text-sm font-medium">Recipients</label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select recipients" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Users</SelectItem>
                  <SelectItem value="premium">Premium Users</SelectItem>
                  <SelectItem value="new">New Users (Last 30 days)</SelectItem>
                  <SelectItem value="inactive">Inactive Users</SelectItem>
                  <SelectItem value="custom">Custom Selection</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="text-sm font-medium">Subject</label>
              <Input placeholder="Email subject" />
            </div>
            
            <div>
              <label className="text-sm font-medium">Message</label>
              <Textarea placeholder="Type your message here" rows={10} />
            </div>
            
            <div className="flex justify-end">
              <Button variant="outline" className="mr-2">Save Draft</Button>
              <Button>Send Email</Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminEmails;
