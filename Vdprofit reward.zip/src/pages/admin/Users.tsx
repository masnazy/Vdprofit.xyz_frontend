
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import { toast } from "@/hooks/use-toast";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { UserType } from "@/pages/Dashboard";

// Extended type that includes id for admin panel usage
interface AdminUserType extends UserType {
  id: number;
}

// Mock users for admin panel
const initialUsers: AdminUserType[] = [
  {
    id: 1,
    name: "John Doe",
    email: "john@example.com",
    wallet: 125.50,
    referralCode: "JOHN123",
    tasksCompleted: 15,
    totalWithdrawal: 50.25,
    totalDeposit: 100.00,
    isPremium: true,
    premiumBalance: 75.00,
    pendingDeposits: 0,
    pendingWithdrawals: 0,
    kycStatus: "approved" as "not_submitted" | "pending" | "approved" | "rejected",
    cryptoWallets: {
      bitcoin: 0.001,
      ethereum: 0.01,
      solana: 0.5,
      avax: 0,
      ada: 0
    }
  },
  {
    id: 2,
    name: "Jane Smith",
    email: "jane@example.com",
    wallet: 75.25,
    referralCode: "JANE456",
    tasksCompleted: 8,
    totalWithdrawal: 25.00,
    totalDeposit: 50.00,
    isPremium: false,
    premiumBalance: 0,
    pendingDeposits: 1,
    pendingWithdrawals: 0,
    kycStatus: "pending" as "not_submitted" | "pending" | "approved" | "rejected",
    cryptoWallets: {
      bitcoin: 0,
      ethereum: 0.005,
      solana: 0,
      avax: 0,
      ada: 0
    }
  }
];

const AdminUsers = () => {
  const [users, setUsers] = useState<AdminUserType[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<AdminUserType[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [selectedUser, setSelectedUser] = useState<AdminUserType | null>(null);
  
  // Form state for new user
  const [newUser, setNewUser] = useState({
    name: "",
    email: "",
    wallet: 0,
    isPremium: false
  });
  
  useEffect(() => {
    // In a real app, this would be an API call
    // For demo purposes, we'll use the mock data
    setUsers(initialUsers);
    setFilteredUsers(initialUsers);
  }, []);
  
  // Filter users when search query changes
  useEffect(() => {
    if (!searchQuery) {
      setFilteredUsers(users);
    } else {
      const filtered = users.filter(user => 
        user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.email.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setFilteredUsers(filtered);
    }
  }, [searchQuery, users]);
  
  const handleAddUser = () => {
    if (!newUser.name || !newUser.email) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }
    
    // Create a new user object
    const userToAdd: AdminUserType = {
      id: users.length + 1,
      name: newUser.name,
      email: newUser.email,
      wallet: newUser.wallet,
      referralCode: `${newUser.name.substring(0, 4).toUpperCase()}${Math.floor(Math.random() * 1000)}`,
      tasksCompleted: 0,
      totalWithdrawal: 0,
      totalDeposit: 0,
      isPremium: newUser.isPremium,
      premiumBalance: 0,
      pendingDeposits: 0,
      pendingWithdrawals: 0,
      kycStatus: "not_submitted",
      cryptoWallets: {
        bitcoin: 0,
        ethereum: 0,
        solana: 0,
        avax: 0,
        ada: 0
      }
    };
    
    setUsers([...users, userToAdd]);
    
    toast({
      title: "User added",
      description: `${userToAdd.name} has been added successfully.`,
    });
    
    // Reset the form and close the dialog
    setNewUser({
      name: "",
      email: "",
      wallet: 0,
      isPremium: false
    });
    setShowAddDialog(false);
  };
  
  const handleEditUser = () => {
    if (!selectedUser) return;
    
    // Update the user in the array
    const updatedUsers = users.map(user => 
      user.id === selectedUser.id ? selectedUser : user
    );
    
    setUsers(updatedUsers);
    
    toast({
      title: "User updated",
      description: `${selectedUser.name}'s information has been updated.`,
    });
    
    setShowEditDialog(false);
  };
  
  const handleDeleteUser = (id: number) => {
    const updatedUsers = users.filter(user => user.id !== id);
    setUsers(updatedUsers);
    
    toast({
      title: "User deleted",
      description: "The user has been removed successfully.",
    });
  };
  
  const handleApproveKyc = (id: number) => {
    const updatedUsers = users.map(user => {
      if (user.id === id) {
        return {
          ...user,
          kycStatus: "approved" as "not_submitted" | "pending" | "approved" | "rejected"
        };
      }
      return user;
    });
    
    setUsers(updatedUsers);
    
    toast({
      title: "KYC Approved",
      description: "The user's KYC has been approved.",
    });
  };
  
  const handleApproveDeposit = (id: number) => {
    const updatedUsers = users.map(user => {
      if (user.id === id && user.pendingDeposits && user.pendingDeposits > 0) {
        return {
          ...user,
          pendingDeposits: user.pendingDeposits - 1,
          wallet: user.wallet + 100, // Example amount
          totalDeposit: user.totalDeposit + 100
        };
      }
      return user;
    });
    
    setUsers(updatedUsers);
    
    toast({
      title: "Deposit Approved",
      description: "The user's deposit has been approved and added to their wallet.",
    });
  };

  return (
    <div className="container py-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">User Management</h1>
        <Button onClick={() => setShowAddDialog(true)}>Add New User</Button>
      </div>
      
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>All Users</CardTitle>
          <div className="flex items-center space-x-2">
            <Input 
              placeholder="Search users..." 
              className="w-[250px]" 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Button variant="outline" onClick={() => setSearchQuery("")}>
              Clear
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Balance</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>KYC</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredUsers.map((user) => (
                <TableRow key={user.id}>
                  <TableCell className="font-medium">{user.name}</TableCell>
                  <TableCell>{user.email}</TableCell>
                  <TableCell>${user.wallet.toFixed(2)}</TableCell>
                  <TableCell>
                    <Badge variant={user.isPremium ? "outline" : "secondary"}>
                      {user.isPremium ? "Premium" : "Standard"}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {user.kycStatus === "approved" ? (
                      <Badge className="bg-green-100 text-green-800">Approved</Badge>
                    ) : user.kycStatus === "pending" ? (
                      <Badge className="bg-yellow-100 text-yellow-800">Pending</Badge>
                    ) : user.kycStatus === "rejected" ? (
                      <Badge variant="destructive">Rejected</Badge>
                    ) : (
                      <Badge variant="outline">Not Submitted</Badge>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => {
                          setSelectedUser(user);
                          setShowEditDialog(true);
                        }}
                      >
                        Edit
                      </Button>
                      {user.kycStatus === "pending" && (
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="bg-green-50 text-green-700 hover:bg-green-100"
                          onClick={() => handleApproveKyc(user.id)}
                        >
                          Approve KYC
                        </Button>
                      )}
                      {user.pendingDeposits && user.pendingDeposits > 0 && (
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="bg-blue-50 text-blue-700 hover:bg-blue-100"
                          onClick={() => handleApproveDeposit(user.id)}
                        >
                          Approve Deposit
                        </Button>
                      )}
                      <Button 
                        variant="destructive" 
                        size="sm"
                        onClick={() => handleDeleteUser(user.id)}
                      >
                        Delete
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      
      {/* Add User Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Add New User</DialogTitle>
            <DialogDescription>
              Create a new user account.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="name">Full Name</Label>
              <Input 
                id="name" 
                value={newUser.name} 
                onChange={(e) => setNewUser({ ...newUser, name: e.target.value })} 
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="email">Email</Label>
              <Input 
                id="email" 
                type="email" 
                value={newUser.email} 
                onChange={(e) => setNewUser({ ...newUser, email: e.target.value })} 
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="wallet">Initial Balance</Label>
              <Input 
                id="wallet" 
                type="number"
                step="0.01"
                value={newUser.wallet} 
                onChange={(e) => setNewUser({ ...newUser, wallet: parseFloat(e.target.value) || 0 })} 
              />
            </div>
            <div className="flex items-center space-x-2">
              <Switch 
                id="premium" 
                checked={newUser.isPremium}
                onCheckedChange={(checked) => setNewUser({ ...newUser, isPremium: checked })}
              />
              <Label htmlFor="premium">Premium Account</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddDialog(false)}>Cancel</Button>
            <Button onClick={handleAddUser}>Add User</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Edit User Dialog */}
      {selectedUser && (
        <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Edit User</DialogTitle>
              <DialogDescription>
                Update user account information.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="edit-name">Full Name</Label>
                <Input 
                  id="edit-name" 
                  value={selectedUser.name} 
                  onChange={(e) => setSelectedUser({ ...selectedUser, name: e.target.value })} 
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-email">Email</Label>
                <Input 
                  id="edit-email" 
                  type="email" 
                  value={selectedUser.email} 
                  onChange={(e) => setSelectedUser({ ...selectedUser, email: e.target.value })} 
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-wallet">Balance</Label>
                <Input 
                  id="edit-wallet" 
                  type="number"
                  step="0.01"
                  value={selectedUser.wallet} 
                  onChange={(e) => setSelectedUser({ ...selectedUser, wallet: parseFloat(e.target.value) || 0 })} 
                />
              </div>
              <div className="flex items-center space-x-2">
                <Switch 
                  id="edit-premium" 
                  checked={selectedUser.isPremium}
                  onCheckedChange={(checked) => setSelectedUser({ ...selectedUser, isPremium: checked })}
                />
                <Label htmlFor="edit-premium">Premium Account</Label>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowEditDialog(false)}>Cancel</Button>
              <Button onClick={handleEditUser}>Save Changes</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

export default AdminUsers;
