import { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";
import { Bitcoin, Wallet, CircleDollarSign } from "lucide-react";
import { UserType } from "@/pages/Dashboard";

type CryptoWalletProps = {
  user: UserType;
  setUser: React.Dispatch<React.SetStateAction<UserType | null>>;
};

// Exchange rates (simplified)
const exchangeRates: Record<string, Record<string, number>> = {
  usd: { bitcoin: 0.000036, ethereum: 0.00062, solana: 0.051, avax: 0.086, ada: 2.75 },
  bitcoin: { usd: 27500, ethereum: 17.2, solana: 1400, avax: 2400, ada: 80000 },
  ethereum: { usd: 1600, bitcoin: 0.058, solana: 85, avax: 142, ada: 4800 },
  solana: { usd: 19.5, bitcoin: 0.00071, ethereum: 0.0118, avax: 1.65, ada: 53 },
  avax: { usd: 11.5, bitcoin: 0.00042, ethereum: 0.007, solana: 0.6, ada: 32 },
  ada: { usd: 0.38, bitcoin: 0.000012, ethereum: 0.00021, solana: 0.019, avax: 0.031 }
};

export function CryptoWallet({ user, setUser }: CryptoWalletProps) {
  const [isConvertDialogOpen, setIsConvertDialogOpen] = useState(false);
  const [fromCurrency, setFromCurrency] = useState<string>("usd");
  const [toCurrency, setToCurrency] = useState<string>("bitcoin");
  const [convertAmount, setConvertAmount] = useState("");
  
  // Safety helper function to prevent null/undefined errors
  const safeNumber = (value: number | undefined | null): number => {
    return typeof value === 'number' ? value : 0;
  };
  
  const getCryptoIcon = (crypto: string) => {
    switch(crypto) {
      case "bitcoin": return <Bitcoin className="h-4 w-4" />;
      case "ethereum": return <CircleDollarSign className="h-4 w-4" />;
      default: return <Wallet className="h-4 w-4" />;
    }
  };
  
  const getMaxAmount = () => {
    if (!user || !user.cryptoWallets) return 0;
    
    switch(fromCurrency) {
      case "usd": return safeNumber(user.wallet);
      case "bitcoin": return safeNumber(user.cryptoWallets.bitcoin);
      case "ethereum": return safeNumber(user.cryptoWallets.ethereum);
      case "solana": return safeNumber(user.cryptoWallets.solana);
      case "avax": return safeNumber(user.cryptoWallets.avax);
      case "ada": return safeNumber(user.cryptoWallets.ada);
      default: return 0;
    }
  };
  
  const handleConvert = () => {
    if (!user || !user.cryptoWallets) {
      toast({
        title: "Error",
        description: "User data is not available",
        variant: "destructive",
      });
      return;
    }
    
    const amount = parseFloat(convertAmount);
    if (isNaN(amount) || amount <= 0) {
      toast({
        title: "Invalid amount",
        description: "Please enter a valid positive number",
        variant: "destructive",
      });
      return;
    }
    
    const maxAmount = getMaxAmount();
    if (amount > maxAmount) {
      toast({
        title: "Insufficient funds",
        description: `You don't have enough ${fromCurrency.toUpperCase()} for this conversion`,
        variant: "destructive",
      });
      return;
    }
    
    // Calculate conversion based on exchange rates
    const conversionRate = exchangeRates[fromCurrency]?.[toCurrency] || 0;
    const convertedAmount = amount * conversionRate;
    
    // Update user balances
    const updatedUser = { ...user };
    
    // Ensure wallet and cryptoWallets exist
    if (!updatedUser.cryptoWallets) {
      updatedUser.cryptoWallets = {
        bitcoin: 0,
        ethereum: 0,
        solana: 0,
        avax: 0,
        ada: 0
      };
    }
    
    // Subtract from source
    if (fromCurrency === "usd") {
      updatedUser.wallet = safeNumber(updatedUser.wallet) - amount;
    } else {
      const cryptoKey = fromCurrency as keyof typeof updatedUser.cryptoWallets;
      updatedUser.cryptoWallets[cryptoKey] = safeNumber(updatedUser.cryptoWallets[cryptoKey]) - amount;
    }
    
    // Add to destination
    if (toCurrency === "usd") {
      updatedUser.wallet = safeNumber(updatedUser.wallet) + convertedAmount;
    } else {
      const cryptoKey = toCurrency as keyof typeof updatedUser.cryptoWallets;
      updatedUser.cryptoWallets[cryptoKey] = safeNumber(updatedUser.cryptoWallets[cryptoKey]) + convertedAmount;
    }
    
    setUser(updatedUser);
    localStorage.setItem("user", JSON.stringify(updatedUser));
    
    toast({
      title: "Conversion successful",
      description: `Converted ${amount} ${fromCurrency.toUpperCase()} to ${convertedAmount.toFixed(8)} ${toCurrency.toUpperCase()}`,
    });
    
    setIsConvertDialogOpen(false);
    setConvertAmount("");
  };
  
  // Ensure user and cryptoWallets exist before rendering
  if (!user || !user.cryptoWallets) {
    return (
      <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 border-blue-100 dark:border-blue-800">
        <CardHeader>
          <CardTitle className="text-blue-800 dark:text-blue-300">Crypto Wallets</CardTitle>
          <CardDescription>Loading wallet data...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-40 flex items-center justify-center">
            <p>Loading wallet information...</p>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <>
      <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 border-blue-100 dark:border-blue-800">
        <CardHeader>
          <CardTitle className="text-blue-800 dark:text-blue-300">Crypto Wallets</CardTitle>
          <CardDescription>Your cryptocurrency balances</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <div className="flex items-center">
                <Bitcoin className="h-5 w-5 mr-2 text-amber-500" />
                <span>Bitcoin</span>
              </div>
              <span className="font-medium">{safeNumber(user.cryptoWallets.bitcoin).toFixed(8)} BTC</span>
            </div>
            <div className="flex justify-between items-center">
              <div className="flex items-center">
                <CircleDollarSign className="h-5 w-5 mr-2 text-indigo-500" />
                <span>Ethereum</span>
              </div>
              <span className="font-medium">{safeNumber(user.cryptoWallets.ethereum).toFixed(8)} ETH</span>
            </div>
            <div className="flex justify-between items-center">
              <div className="flex items-center">
                <Wallet className="h-5 w-5 mr-2 text-purple-500" />
                <span>Solana</span>
              </div>
              <span className="font-medium">{safeNumber(user.cryptoWallets.solana).toFixed(8)} SOL</span>
            </div>
            <div className="flex justify-between items-center">
              <div className="flex items-center">
                <Wallet className="h-5 w-5 mr-2 text-red-500" />
                <span>Avalanche</span>
              </div>
              <span className="font-medium">{safeNumber(user.cryptoWallets.avax).toFixed(8)} AVAX</span>
            </div>
            <div className="flex justify-between items-center">
              <div className="flex items-center">
                <Wallet className="h-5 w-5 mr-2 text-blue-500" />
                <span>Cardano</span>
              </div>
              <span className="font-medium">{safeNumber(user.cryptoWallets.ada).toFixed(8)} ADA</span>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={() => setIsConvertDialogOpen(true)} className="w-full bg-blue-600 hover:bg-blue-700">
            Convert Currency
          </Button>
        </CardFooter>
      </Card>
      
      <Dialog open={isConvertDialogOpen} onOpenChange={setIsConvertDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Convert Currency</DialogTitle>
            <DialogDescription>
              Exchange between USD and cryptocurrencies
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="fromCurrency">From</Label>
                <Select 
                  value={fromCurrency} 
                  onValueChange={setFromCurrency}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="usd">USD (Available Balance)</SelectItem>
                    <SelectItem value="bitcoin">Bitcoin (BTC)</SelectItem>
                    <SelectItem value="ethereum">Ethereum (ETH)</SelectItem>
                    <SelectItem value="solana">Solana (SOL)</SelectItem>
                    <SelectItem value="avax">Avalanche (AVAX)</SelectItem>
                    <SelectItem value="ada">Cardano (ADA)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="toCurrency">To</Label>
                <Select 
                  value={toCurrency} 
                  onValueChange={setToCurrency}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="usd">USD (Available Balance)</SelectItem>
                    <SelectItem value="bitcoin">Bitcoin (BTC)</SelectItem>
                    <SelectItem value="ethereum">Ethereum (ETH)</SelectItem>
                    <SelectItem value="solana">Solana (SOL)</SelectItem>
                    <SelectItem value="avax">Avalanche (AVAX)</SelectItem>
                    <SelectItem value="ada">Cardano (ADA)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div>
              <Label htmlFor="amount">Amount</Label>
              <div className="flex items-center mt-1">
                <Input
                  id="amount"
                  value={convertAmount}
                  onChange={(e) => setConvertAmount(e.target.value)}
                  type="number"
                  min="0"
                  step="any"
                  className="flex-1"
                />
                <Button 
                  variant="outline" 
                  className="ml-2"
                  onClick={() => setConvertAmount(getMaxAmount().toString())}
                >
                  Max
                </Button>
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Available: {getMaxAmount().toFixed(fromCurrency === "usd" ? 2 : 8)} {fromCurrency.toUpperCase()}
              </p>
            </div>
            
            {fromCurrency !== toCurrency && convertAmount && !isNaN(parseFloat(convertAmount)) && (
              <div className="bg-muted p-3 rounded-md">
                <p className="text-sm">
                  <span className="font-medium">Conversion Rate:</span> 
                  {(() => {
                    const rate = exchangeRates[fromCurrency]?.[toCurrency];
                    return rate !== undefined ? rate.toFixed(8) : '0';
                  })()} {toCurrency.toUpperCase()}
                </p>
                <p className="text-sm mt-1">
                  <span className="font-medium">You will receive:</span> 
                  {(() => {
                    const rate = exchangeRates[fromCurrency]?.[toCurrency] || 0;
                    return (parseFloat(convertAmount) * rate).toFixed(8);
                  })()} {toCurrency.toUpperCase()}
                </p>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsConvertDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleConvert}
              disabled={fromCurrency === toCurrency || !convertAmount || isNaN(parseFloat(convertAmount)) || parseFloat(convertAmount) <= 0}
            >
              Convert
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
