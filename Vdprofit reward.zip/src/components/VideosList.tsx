
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { toast } from "@/hooks/use-toast";
import { UserType } from "@/pages/Dashboard";

// Updated mock video data with videoUrl
const MOCK_VIDEOS = [
  {
    id: 1,
    title: "How to Earn Rewards on Our Platform",
    thumbnail: "/placeholder.svg",
    duration: "5:32",
    reward: 0.5,
    code: "WATCH123",
    videoUrl: "https://example.com/video1.mp4",
  },
  {
    id: 2,
    title: "Top 10 Money Making Tips",
    thumbnail: "/placeholder.svg",
    duration: "8:15",
    reward: 0.75,
    code: "WATCH456",
    videoUrl: "https://youtube.com/watch?v=example2",
  },
  {
    id: 3,
    title: "Maximize Your Referral Earnings",
    thumbnail: "/placeholder.svg",
    duration: "4:45",
    reward: 0.5,
    code: "WATCH789",
    videoUrl: "https://vimeo.com/example3",
  },
  {
    id: 4,
    title: "Understanding Digital Wallets",
    thumbnail: "/placeholder.svg",
    duration: "7:20",
    reward: 0.6,
    code: "WATCHABC",
    videoUrl: "https://example.com/video4.mp4",
  },
];

type VideosListProps = {
  user: UserType;
  setUser: React.Dispatch<React.SetStateAction<UserType | null>>;
};

export function VideosList({ user, setUser }: VideosListProps) {
  const [selectedVideo, setSelectedVideo] = useState<typeof MOCK_VIDEOS[0] | null>(null);
  const [verificationCode, setVerificationCode] = useState("");
  const [verificationDialogOpen, setVerificationDialogOpen] = useState(false);

  const handleWatchVideo = (video: typeof MOCK_VIDEOS[0]) => {
    setSelectedVideo(video);
    
    // Open the video URL in a new tab
    if (video.videoUrl) {
      window.open(video.videoUrl, '_blank');
      
      // Show verification dialog after a short delay
      setTimeout(() => {
        setVerificationDialogOpen(true);
      }, 1000);
    } else {
      toast({
        title: "Video URL missing",
        description: "This video cannot be played at the moment.",
        variant: "destructive",
      });
    }
  };

  const verifyWatched = () => {
    if (!selectedVideo) return;
    
    if (verificationCode.toUpperCase() === selectedVideo.code) {
      // Success! Award the user
      const rewardMultiplier = user.isPremium ? 1.5 : 1;
      const earnedReward = selectedVideo.reward * rewardMultiplier;
      
      const updatedUser = {
        ...user,
        wallet: user.wallet + earnedReward,
        tasksCompleted: user.tasksCompleted + 1
      };
      
      setUser(updatedUser);
      localStorage.setItem("user", JSON.stringify(updatedUser));
      
      toast({
        title: "Verification successful!",
        description: `You earned $${earnedReward.toFixed(2)} for watching this video!`,
      });
    } else {
      toast({
        title: "Verification failed",
        description: "The code you entered is incorrect. Please try again.",
        variant: "destructive",
      });
    }
    
    setVerificationDialogOpen(false);
    setVerificationCode("");
  };

  const safeNumber = (value: any): number => {
    if (value === undefined || value === null) return 0;
    const num = Number(value);
    return isNaN(num) ? 0 : num;
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Available Videos</h2>
        <div className="space-x-2">
          {user.isPremium && <span className="px-3 py-1 bg-amber-100 text-amber-800 rounded-full text-sm">Premium User (1.5x rewards)</span>}
          <Button variant="outline">Refresh</Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {MOCK_VIDEOS.map((video) => (
          <Card key={video.id} className="overflow-hidden">
            <div className="relative">
              <img 
                src={video.thumbnail} 
                alt={video.title} 
                className="w-full aspect-video object-cover"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = "/placeholder.svg";
                }}
              />
              <span className="absolute bottom-2 right-2 bg-black bg-opacity-70 text-white text-xs px-2 py-1 rounded">
                {video.duration}
              </span>
            </div>
            <div className="p-4">
              <h3 className="font-medium mb-2">{video.title}</h3>
              <div className="flex justify-between items-center">
                <span className="text-green-600 font-semibold">
                  Earn ${(safeNumber(video.reward) * (user.isPremium ? 1.5 : 1)).toFixed(2)}
                  {user.isPremium && <span className="text-xs ml-1">(Premium bonus)</span>}
                </span>
                <Button size="sm" onClick={() => handleWatchVideo(video)}>
                  Watch
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
      
      <Dialog open={verificationDialogOpen} onOpenChange={setVerificationDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Verify You Watched the Video</DialogTitle>
            <DialogDescription>
              Please enter the verification code shown at the end of the video to earn your reward.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Input
              value={verificationCode}
              onChange={(e) => setVerificationCode(e.target.value)}
              placeholder="Enter verification code"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setVerificationDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={verifyWatched}>
              Submit
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
