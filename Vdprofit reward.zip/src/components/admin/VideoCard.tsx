
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Video } from "@/types/video";

interface VideoCardProps {
  video: Video;
  onEdit: (video: Video) => void;
  onDelete: (id: number) => void;
}

export function VideoCard({ video, onEdit, onDelete }: VideoCardProps) {
  // Add safety check for video data
  if (!video) {
    return null;
  }

  // Handle potential undefined values
  const title = video.title || "Untitled Video";
  const thumbnail = video.thumbnail || "/placeholder.svg";
  const duration = video.duration || "0:00";
  
  // Safety checks for numerical values
  const safeNumber = (value: any): number => {
    if (value === undefined || value === null) return 0;
    const num = Number(value);
    return isNaN(num) ? 0 : num;
  };
  
  const reward = safeNumber(video.reward);
  const code = video.code || "";
  const id = safeNumber(video.id);
  const videoUrl = video.videoUrl || "";

  return (
    <Card key={id} className="overflow-hidden">
      <CardContent className="p-0">
        <div className="flex">
          <div className="w-48 h-32 bg-gray-200">
            <img 
              src={thumbnail} 
              alt={title} 
              className="w-full h-full object-cover"
              onError={(e) => {
                (e.target as HTMLImageElement).src = "/placeholder.svg";
              }}
            />
          </div>
          <div className="flex-1 p-4">
            <h3 className="font-medium mb-2">{title}</h3>
            <div className="grid grid-cols-3 gap-4 text-sm mb-3">
              <div>
                <span className="font-medium">Duration:</span> {duration}
              </div>
              <div>
                <span className="font-medium">Reward:</span> ${reward.toFixed(2)}
              </div>
              <div>
                <span className="font-medium">Code:</span> 
                <span className="ml-1 bg-green-100 text-green-800 px-2 py-0.5 rounded text-xs">
                  {code}
                </span>
              </div>
            </div>
            <div className="text-sm mb-3">
              <span className="font-medium">URL:</span> 
              <span className="ml-1 text-blue-600 truncate block max-w-xs">
                {videoUrl || "Not set"}
              </span>
            </div>
            <div className="flex justify-end">
              <Button 
                variant="outline" 
                size="sm" 
                className="mr-2"
                onClick={() => onEdit(video)}
              >
                Edit
              </Button>
              <Button 
                variant="destructive" 
                size="sm"
                onClick={() => onDelete(id)}
              >
                Delete
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
