
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { toast } from "@/hooks/use-toast";
import { VideoCard } from "@/components/admin/VideoCard";
import { AddVideoDialog } from "@/components/admin/AddVideoDialog";
import { EditVideoDialog } from "@/components/admin/EditVideoDialog";
import { generateRandomVideoCode } from "@/utils/videoUtils";
import { Video } from "@/types/video";

// Mock video data
const MOCK_VIDEOS = [
  {
    id: 1,
    title: "How to Earn Rewards on Our Platform",
    thumbnail: "/placeholder.svg",
    duration: "5:32",
    reward: 0.5,
    code: "WATCH123",
    videoUrl: "https://example.com/video1.mp4",
  },
  {
    id: 2,
    title: "Top 10 Money Making Tips",
    thumbnail: "/placeholder.svg",
    duration: "8:15",
    reward: 0.75,
    code: "WATCH456",
    videoUrl: "https://example.com/video2.mp4",
  },
  {
    id: 3,
    title: "Maximize Your Referral Earnings",
    thumbnail: "/placeholder.svg",
    duration: "4:45",
    reward: 0.5,
    code: "WATCH789",
    videoUrl: "https://example.com/video3.mp4",
  },
  {
    id: 4,
    title: "Understanding Digital Wallets",
    thumbnail: "/placeholder.svg",
    duration: "7:20",
    reward: 0.6,
    code: "WATCHABC",
    videoUrl: "https://example.com/video4.mp4",
  },
];

export function AdminVideoManager() {
  const [videos, setVideos] = useState<Video[]>(MOCK_VIDEOS);
  const [newVideoDialogOpen, setNewVideoDialogOpen] = useState(false);
  const [editVideoDialogOpen, setEditVideoDialogOpen] = useState(false);
  const [selectedVideo, setSelectedVideo] = useState<null | Video>(null);
  
  const handleAddVideo = (newVideo: any) => {
    // Validation would go here
    const videoToAdd = {
      id: videos.length + 1,
      title: newVideo.title,
      thumbnail: newVideo.thumbnail || "/placeholder.svg",
      duration: newVideo.duration,
      reward: parseFloat(newVideo.reward) || 0,
      code: newVideo.code.toUpperCase(),
      videoUrl: newVideo.videoUrl,
    };
    
    setVideos([...videos, videoToAdd]);
    setNewVideoDialogOpen(false);
    
    toast({
      title: "Video added",
      description: `${videoToAdd.title} has been added successfully.`,
    });
  };

  const handleEditVideo = () => {
    if (!selectedVideo) return;
    
    const updatedVideos = videos.map(video => 
      video.id === selectedVideo.id ? selectedVideo : video
    );
    
    setVideos(updatedVideos);
    setEditVideoDialogOpen(false);
    
    toast({
      title: "Video updated",
      description: `${selectedVideo.title} has been updated successfully.`,
    });
  };

  const handleDeleteVideo = (id: number) => {
    const updatedVideos = videos.filter(video => video.id !== id);
    setVideos(updatedVideos);
    
    toast({
      title: "Video deleted",
      description: "The video has been removed successfully.",
    });
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Manage Videos</h2>
        <Button onClick={() => setNewVideoDialogOpen(true)}>Add New Video</Button>
      </div>
      
      <div className="grid grid-cols-1 gap-4">
        {videos.map(video => (
          <VideoCard 
            key={video.id}
            video={video}
            onEdit={(video) => {
              setSelectedVideo(video);
              setEditVideoDialogOpen(true);
            }}
            onDelete={handleDeleteVideo}
          />
        ))}
      </div>
      
      {/* Add New Video Dialog */}
      <AddVideoDialog
        open={newVideoDialogOpen}
        onOpenChange={setNewVideoDialogOpen}
        onAdd={handleAddVideo}
        generateRandomCode={generateRandomVideoCode}
      />
      
      {/* Edit Video Dialog */}
      <EditVideoDialog
        open={editVideoDialogOpen}
        onOpenChange={setEditVideoDialogOpen}
        onSave={handleEditVideo}
        selectedVideo={selectedVideo}
        setSelectedVideo={setSelectedVideo}
        generateRandomCode={generateRandomVideoCode}
      />
    </div>
  );
}
