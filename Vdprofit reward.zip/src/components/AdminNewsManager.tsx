
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/hooks/use-toast";

// Mock news data
const MOCK_NEWS = [
  {
    id: 1,
    title: "New Feature: Earn More by Referring Friends",
    excerpt: "Our platform now offers increased rewards for referrals. Learn how you can maximize your earnings through our referral program.",
    date: "2023-05-07",
    readTime: "3 min read",
    reward: 0.2,
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam euismod, nisl eget ultricies ultrices, nisl nisl aliquet nisl, eget aliquet nisl nisl eget nisl. Nullam euismod, nisl eget ultricies ultrices, nisl nisl aliquet nisl, eget aliquet nisl nisl eget nisl."
  },
  {
    id: 2,
    title: "Market Trends: Cryptocurrency on the Rise",
    excerpt: "Recent developments in the cryptocurrency market show promising growth. Stay informed about the latest trends.",
    date: "2023-05-05",
    readTime: "5 min read",
    reward: 0.3,
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam euismod, nisl eget ultricies ultrices, nisl nisl aliquet nisl, eget aliquet nisl nisl eget nisl. Nullam euismod, nisl eget ultricies ultrices, nisl nisl aliquet nisl, eget aliquet nisl nisl eget nisl."
  },
  {
    id: 3,
    title: "Tips for Maximizing Your Rewards",
    excerpt: "Learn the best strategies to earn more rewards on our platform. Simple techniques can significantly increase your earnings.",
    date: "2023-05-03",
    readTime: "4 min read",
    reward: 0.25,
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam euismod, nisl eget ultricies ultrices, nisl nisl aliquet nisl, eget aliquet nisl nisl eget nisl. Nullam euismod, nisl eget ultricies ultrices, nisl nisl aliquet nisl, eget aliquet nisl nisl eget nisl."
  },
];

export function AdminNewsManager() {
  const [news, setNews] = useState(MOCK_NEWS);
  const [newNewsDialogOpen, setNewNewsDialogOpen] = useState(false);
  const [editNewsDialogOpen, setEditNewsDialogOpen] = useState(false);
  const [selectedNews, setSelectedNews] = useState<null | typeof MOCK_NEWS[0]>(null);
  
  // New news form state
  const [newArticle, setNewArticle] = useState({
    title: "",
    excerpt: "",
    content: "",
    readTime: "",
    reward: ""
  });

  const handleAddNews = () => {
    // Get current date
    const currentDate = new Date().toISOString().split('T')[0];
    
    // Validation would go here
    const articleToAdd = {
      id: news.length + 1,
      title: newArticle.title,
      excerpt: newArticle.excerpt,
      content: newArticle.content,
      date: currentDate,
      readTime: newArticle.readTime || "3 min read",
      reward: parseFloat(newArticle.reward) || 0,
    };
    
    setNews([articleToAdd, ...news]);
    setNewNewsDialogOpen(false);
    setNewArticle({
      title: "",
      excerpt: "",
      content: "",
      readTime: "",
      reward: ""
    });
    
    toast({
      title: "Article published",
      description: `${articleToAdd.title} has been published successfully.`,
    });
  };

  const handleEditNews = () => {
    if (!selectedNews) return;
    
    const updatedNews = news.map(article => 
      article.id === selectedNews.id ? selectedNews : article
    );
    
    setNews(updatedNews);
    setEditNewsDialogOpen(false);
    
    toast({
      title: "Article updated",
      description: `${selectedNews.title} has been updated successfully.`,
    });
  };

  const handleDeleteNews = (id: number) => {
    const updatedNews = news.filter(article => article.id !== id);
    setNews(updatedNews);
    
    toast({
      title: "Article deleted",
      description: "The article has been removed successfully.",
    });
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Manage News Articles</h2>
        <Button onClick={() => setNewNewsDialogOpen(true)}>Add New Article</Button>
      </div>
      
      <div className="grid grid-cols-1 gap-4">
        {news.map(article => (
          <Card key={article.id}>
            <CardContent className="p-4">
              <div className="flex flex-col md:flex-row md:justify-between">
                <div className="flex-1">
                  <h3 className="font-medium text-lg mb-1">{article.title}</h3>
                  <p className="text-gray-500 text-sm mb-2">{article.excerpt}</p>
                  <div className="flex text-xs text-gray-500 space-x-4 mb-4">
                    <span>Published: {article.date}</span>
                    <span>{article.readTime}</span>
                    <span>Reward: ${article.reward.toFixed(2)}</span>
                  </div>
                </div>
                <div className="flex items-start space-x-2 mt-4 md:mt-0">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => {
                      setSelectedNews(article);
                      setEditNewsDialogOpen(true);
                    }}
                  >
                    Edit
                  </Button>
                  <Button 
                    variant="destructive" 
                    size="sm"
                    onClick={() => handleDeleteNews(article.id)}
                  >
                    Delete
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      
      {/* Add New Article Dialog */}
      <Dialog open={newNewsDialogOpen} onOpenChange={setNewNewsDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Add New Article</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div>
              <Label htmlFor="title">Title</Label>
              <Input 
                id="title" 
                value={newArticle.title}
                onChange={(e) => setNewArticle({...newArticle, title: e.target.value})}
              />
            </div>
            <div>
              <Label htmlFor="excerpt">Short Excerpt</Label>
              <Textarea 
                id="excerpt" 
                value={newArticle.excerpt}
                onChange={(e) => setNewArticle({...newArticle, excerpt: e.target.value})}
                rows={2}
              />
            </div>
            <div>
              <Label htmlFor="content">Article Content</Label>
              <Textarea 
                id="content" 
                value={newArticle.content}
                onChange={(e) => setNewArticle({...newArticle, content: e.target.value})}
                rows={6}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="readTime">Read Time</Label>
                <Input 
                  id="readTime" 
                  value={newArticle.readTime}
                  onChange={(e) => setNewArticle({...newArticle, readTime: e.target.value})}
                  placeholder="3 min read"
                />
              </div>
              <div>
                <Label htmlFor="reward">Reward Amount ($)</Label>
                <Input 
                  id="reward" 
                  value={newArticle.reward}
                  onChange={(e) => setNewArticle({...newArticle, reward: e.target.value})}
                  type="number"
                  step="0.01"
                  min="0"
                  placeholder="0.20"
                />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setNewNewsDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddNews}>
              Publish Article
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Edit Article Dialog */}
      <Dialog open={editNewsDialogOpen} onOpenChange={setEditNewsDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Edit Article</DialogTitle>
          </DialogHeader>
          {selectedNews && (
            <div className="grid gap-4 py-4">
              <div>
                <Label htmlFor="edit-title">Title</Label>
                <Input 
                  id="edit-title" 
                  value={selectedNews.title}
                  onChange={(e) => setSelectedNews({...selectedNews, title: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="edit-excerpt">Short Excerpt</Label>
                <Textarea 
                  id="edit-excerpt" 
                  value={selectedNews.excerpt}
                  onChange={(e) => setSelectedNews({...selectedNews, excerpt: e.target.value})}
                  rows={2}
                />
              </div>
              <div>
                <Label htmlFor="edit-content">Article Content</Label>
                <Textarea 
                  id="edit-content" 
                  value={selectedNews.content}
                  onChange={(e) => setSelectedNews({...selectedNews, content: e.target.value})}
                  rows={6}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit-readTime">Read Time</Label>
                  <Input 
                    id="edit-readTime" 
                    value={selectedNews.readTime}
                    onChange={(e) => setSelectedNews({...selectedNews, readTime: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="edit-reward">Reward Amount ($)</Label>
                  <Input 
                    id="edit-reward" 
                    value={selectedNews.reward}
                    onChange={(e) => setSelectedNews({...selectedNews, reward: parseFloat(e.target.value) || selectedNews.reward})}
                    type="number"
                    step="0.01"
                    min="0"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="edit-date">Publish Date</Label>
                <Input 
                  id="edit-date" 
                  value={selectedNews.date}
                  onChange={(e) => setSelectedNews({...selectedNews, date: e.target.value})}
                  type="date"
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditNewsDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleEditNews}>
              Update Article
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
