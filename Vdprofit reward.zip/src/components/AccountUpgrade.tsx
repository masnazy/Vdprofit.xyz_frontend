import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Bitcoin, Wallet, CircleDollarSign } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { Input } from "@/components/ui/input";
import { UserType } from "@/pages/Dashboard";

type AccountUpgradeProps = {
  user: UserType;
  setUser: React.Dispatch<React.SetStateAction<UserType | null>>;
};

const PREMIUM_COST = 25;

export function AccountUpgrade({ user, setUser }: AccountUpgradeProps) {
  const [isDepositDialogOpen, setIsDepositDialogOpen] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<string>("bitcoin");
  const [depositAmount, setDepositAmount] = useState("");
  
  const getCryptoIcon = (crypto: string) => {
    switch(crypto) {
      case "bitcoin": return <Bitcoin className="h-4 w-4" />;
      case "ethereum": return <CircleDollarSign className="h-4 w-4" />;
      default: return <Wallet className="h-4 w-4" />;
    }
  };
  
  const handleDeposit = () => {
    const amount = parseFloat(depositAmount);
    if (isNaN(amount) || amount <= 0) {
      toast({
        title: "Invalid amount",
        description: "Please enter a valid positive number",
        variant: "destructive",
      });
      return;
    }
    
    // In a real app, this would be a payment gateway integration
    // For demo purposes, we'll simulate a successful deposit
    
    const updatedUser = { ...user };
    
    // Add the deposit to the wallet
    updatedUser.cryptoWallets[paymentMethod as keyof typeof updatedUser.cryptoWallets] += amount;
    updatedUser.totalDeposit += amount * 10; // Convert to USD for total tracking (simplified)
    
    setUser(updatedUser);
    localStorage.setItem("user", JSON.stringify(updatedUser));
    
    toast({
      title: "Deposit successful",
      description: `${amount} ${paymentMethod.toUpperCase()} has been added to your wallet`,
    });
    
    setIsDepositDialogOpen(false);
    setDepositAmount("");
  };
  
  const handleUpgradeToPremium = () => {
    if (user.isPremium) {
      toast({
        title: "Already a premium member",
        description: "You are already enjoying premium benefits",
      });
      return;
    }
    
    if (user.wallet < PREMIUM_COST) {
      toast({
        title: "Insufficient funds",
        description: `You need at least $${PREMIUM_COST} in your available balance to upgrade`,
        variant: "destructive",
      });
      return;
    }
    
    const updatedUser = {
      ...user,
      wallet: user.wallet - PREMIUM_COST,
      isPremium: true,
      premiumBalance: 10.00 // Starting premium balance
    };
    
    setUser(updatedUser);
    localStorage.setItem("user", JSON.stringify(updatedUser));
    
    toast({
      title: "Account upgraded!",
      description: "You are now a premium member with exclusive benefits",
    });
  };

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="p-6">
          <h3 className="text-lg font-semibold mb-4">Deposit Crypto</h3>
          <p className="text-sm text-muted-foreground mb-4">
            Add funds to your account using cryptocurrency payments
          </p>
          <Button 
            onClick={() => setIsDepositDialogOpen(true)}
            className="w-full"
          >
            Make a Deposit
          </Button>
        </Card>
        
        <Card className="p-6">
          <h3 className="text-lg font-semibold mb-2">Premium Upgrade</h3>
          <p className="text-sm text-muted-foreground mb-2">
            Upgrade your account to premium for just ${PREMIUM_COST}
          </p>
          <ul className="text-sm mb-4">
            <li>• 1.5x rewards on all tasks</li>
            <li>• Priority support</li>
            <li>• Exclusive premium content</li>
          </ul>
          <Button 
            onClick={handleUpgradeToPremium}
            className="w-full"
            variant={user.isPremium ? "outline" : "default"}
            disabled={user.isPremium}
          >
            {user.isPremium ? "Already Premium" : `Upgrade for $${PREMIUM_COST}`}
          </Button>
        </Card>
      </div>
      
      <Dialog open={isDepositDialogOpen} onOpenChange={setIsDepositDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Deposit Cryptocurrency</DialogTitle>
            <DialogDescription>
              Add funds to your account using cryptocurrency
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div>
              <Label>Payment Method</Label>
              <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="bitcoin">
                    <div className="flex items-center">
                      <Bitcoin className="h-4 w-4 mr-2 text-amber-500" />
                      Bitcoin (BTC)
                    </div>
                  </SelectItem>
                  <SelectItem value="ethereum">
                    <div className="flex items-center">
                      <CircleDollarSign className="h-4 w-4 mr-2 text-indigo-500" />
                      Ethereum (ETH)
                    </div>
                  </SelectItem>
                  <SelectItem value="solana">
                    <div className="flex items-center">
                      <Wallet className="h-4 w-4 mr-2 text-purple-500" />
                      Solana (SOL)
                    </div>
                  </SelectItem>
                  <SelectItem value="avax">
                    <div className="flex items-center">
                      <Wallet className="h-4 w-4 mr-2 text-red-500" />
                      Avalanche (AVAX)
                    </div>
                  </SelectItem>
                  <SelectItem value="ada">
                    <div className="flex items-center">
                      <Wallet className="h-4 w-4 mr-2 text-blue-500" />
                      Cardano (ADA)
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-1">
              <Label>Amount</Label>
              <Input
                value={depositAmount}
                onChange={(e) => setDepositAmount(e.target.value)}
                type="number"
                min="0"
                step="any"
                placeholder="0.00"
              />
            </div>
            
            <div className="bg-muted p-4 rounded-md">
              <h4 className="font-medium text-sm mb-2">Deposit Instructions</h4>
              <p className="text-xs text-muted-foreground mb-2">
                In a real application, you would see a QR code or wallet address here.
                For demo purposes, clicking "Deposit" will simulate a successful transaction.
              </p>
              <div className="bg-background p-3 rounded border border-dashed flex items-center justify-center">
                <p className="text-xs font-mono">bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh</p>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDepositDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleDeposit}>
              Deposit
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
