
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "@/hooks/use-toast";

// Mock news data
const MOCK_NEWS = [
  {
    id: 1,
    title: "New Feature: Earn More by Referring Friends",
    excerpt: "Our platform now offers increased rewards for referrals. Learn how you can maximize your earnings through our referral program.",
    date: "2023-05-07",
    readTime: "3 min read",
    reward: 0.2,
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam euismod, nisl eget ultricies ultrices, nisl nisl aliquet nisl, eget aliquet nisl nisl eget nisl. Nullam euismod, nisl eget ultricies ultrices, nisl nisl aliquet nisl, eget aliquet nisl nisl eget nisl. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam euismod, nisl eget ultricies ultrices, nisl nisl aliquet nisl, eget aliquet nisl nisl eget nisl. Nullam euismod, nisl eget ultricies ultrices, nisl nisl aliquet nisl, eget aliquet nisl nisl eget nisl."
  },
  {
    id: 2,
    title: "Market Trends: Cryptocurrency on the Rise",
    excerpt: "Recent developments in the cryptocurrency market show promising growth. Stay informed about the latest trends.",
    date: "2023-05-05",
    readTime: "5 min read",
    reward: 0.3,
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam euismod, nisl eget ultricies ultrices, nisl nisl aliquet nisl, eget aliquet nisl nisl eget nisl. Nullam euismod, nisl eget ultricies ultrices, nisl nisl aliquet nisl, eget aliquet nisl nisl eget nisl. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam euismod, nisl eget ultricies ultrices, nisl nisl aliquet nisl, eget aliquet nisl nisl eget nisl. Nullam euismod, nisl eget ultricies ultrices, nisl nisl aliquet nisl, eget aliquet nisl nisl eget nisl."
  },
  {
    id: 3,
    title: "Tips for Maximizing Your Rewards",
    excerpt: "Learn the best strategies to earn more rewards on our platform. Simple techniques can significantly increase your earnings.",
    date: "2023-05-03",
    readTime: "4 min read",
    reward: 0.25,
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam euismod, nisl eget ultricies ultrices, nisl nisl aliquet nisl, eget aliquet nisl nisl eget nisl. Nullam euismod, nisl eget ultricies ultrices, nisl nisl aliquet nisl, eget aliquet nisl nisl eget nisl. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam euismod, nisl eget ultricies ultrices, nisl nisl aliquet nisl, eget aliquet nisl nisl eget nisl. Nullam euismod, nisl eget ultricies ultrices, nisl nisl aliquet nisl, eget aliquet nisl nisl eget nisl."
  },
  {
    id: 4,
    title: "Upcoming Features on Our Platform",
    excerpt: "We're excited to announce several new features coming to our platform. Stay tuned for these exciting changes.",
    date: "2023-05-01",
    readTime: "3 min read",
    reward: 0.2,
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam euismod, nisl eget ultricies ultrices, nisl nisl aliquet nisl, eget aliquet nisl nisl eget nisl. Nullam euismod, nisl eget ultricies ultrices, nisl nisl aliquet nisl, eget aliquet nisl nisl eget nisl. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam euismod, nisl eget ultricies ultrices, nisl nisl aliquet nisl, eget aliquet nisl nisl eget nisl. Nullam euismod, nisl eget ultricies ultrices, nisl nisl aliquet nisl, eget aliquet nisl nisl eget nisl."
  },
];

export function NewsList() {
  const [selectedArticle, setSelectedArticle] = useState<typeof MOCK_NEWS[0] | null>(null);
  const [readArticles, setReadArticles] = useState<number[]>([]);

  const handleReadArticle = (article: typeof MOCK_NEWS[0]) => {
    setSelectedArticle(article);
    
    // If the user hasn't already read this article, reward them
    if (!readArticles.includes(article.id)) {
      const newReadArticles = [...readArticles, article.id];
      setReadArticles(newReadArticles);
      
      // Update user wallet
      const user = JSON.parse(localStorage.getItem("user") || "{}");
      user.wallet = (user.wallet || 0) + article.reward;
      localStorage.setItem("user", JSON.stringify(user));
      
      // Show toast notification
      toast({
        title: "Reward earned!",
        description: `You earned $${article.reward.toFixed(2)} for reading this article.`,
      });
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Latest News</h2>
        <Button variant="outline">Refresh</Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {MOCK_NEWS.map((article) => (
          <Card key={article.id} className="p-5">
            <div className="mb-4">
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-medium text-lg">{article.title}</h3>
                {readArticles.includes(article.id) && (
                  <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">Read</span>
                )}
              </div>
              <p className="text-gray-600 text-sm mb-2">{article.excerpt}</p>
              <div className="flex justify-between text-xs text-gray-500">
                <span>{article.date}</span>
                <span>{article.readTime}</span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-green-600 font-semibold">
                {readArticles.includes(article.id) ? "Earned $" + article.reward.toFixed(2) : "Earn $" + article.reward.toFixed(2)}
              </span>
              <Button 
                variant={readArticles.includes(article.id) ? "outline" : "default"} 
                size="sm" 
                onClick={() => handleReadArticle(article)}
              >
                {readArticles.includes(article.id) ? "Read Again" : "Read Now"}
              </Button>
            </div>
          </Card>
        ))}
      </div>
      
      <Dialog open={!!selectedArticle} onOpenChange={() => setSelectedArticle(null)}>
        <DialogContent className="sm:max-w-[800px]">
          <DialogHeader>
            <DialogTitle>{selectedArticle?.title}</DialogTitle>
            <div className="flex text-xs text-gray-500 space-x-4 mt-2">
              <span>Published: {selectedArticle?.date}</span>
              <span>{selectedArticle?.readTime}</span>
            </div>
          </DialogHeader>
          <div className="py-4">
            <p className="mb-4">{selectedArticle?.content}</p>
            <p className="mb-4">{selectedArticle?.content}</p>
            <p>{selectedArticle?.content}</p>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
