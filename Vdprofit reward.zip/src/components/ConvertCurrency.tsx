
import { useState } from "react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";
import { UserType } from "@/pages/Dashboard";

type ConvertCurrencyProps = {
  user: UserType;
  setUser: React.Dispatch<React.SetStateAction<UserType | null>>;
};

const CURRENCIES = {
  usd: { name: "USD", rate: 1 },
  btc: { name: "Bitcoin", rate: 0.000024 },
  eth: { name: "Ethereum", rate: 0.00036 },
  sol: { name: "Solana", rate: 0.0125 },
  avax: { name: "Avalanche", rate: 0.035 },
  ada: { name: "Cardano", rate: 0.33 }
};

export function ConvertCurrency({ user, setUser }: ConvertCurrencyProps) {
  const [fromCurrency, setFromCurrency] = useState("usd");
  const [toCurrency, setToCurrency] = useState("btc");
  const [amount, setAmount] = useState("");
  const [convertedAmount, setConvertedAmount] = useState("");
  
  const calculateConversion = () => {
    if (!amount || isNaN(Number(amount))) {
      toast({
        title: "Invalid amount",
        description: "Please enter a valid number",
        variant: "destructive",
      });
      return;
    }
    
    const numAmount = parseFloat(amount);
    if (numAmount <= 0) {
      toast({
        title: "Invalid amount",
        description: "Amount must be greater than zero",
        variant: "destructive",
      });
      return;
    }
    
    // Convert from source currency to USD, then to target currency
    const usdValue = numAmount / CURRENCIES[fromCurrency as keyof typeof CURRENCIES].rate;
    const targetValue = usdValue * CURRENCIES[toCurrency as keyof typeof CURRENCIES].rate;
    
    setConvertedAmount(targetValue.toFixed(8));
  };
  
  const handleConvert = () => {
    if (!convertedAmount || fromCurrency === toCurrency) return;
    
    const numAmount = parseFloat(amount);
    
    // Check if user has sufficient balance
    if (fromCurrency === "usd") {
      if (user.wallet < numAmount) {
        toast({
          title: "Insufficient balance",
          description: "You don't have enough funds in your wallet",
          variant: "destructive",
        });
        return;
      }
      
      // Update user wallet
      const updatedUser = { ...user };
      updatedUser.wallet -= numAmount;
      
      // Update crypto wallet
      if (toCurrency === "btc") updatedUser.cryptoWallets.bitcoin += parseFloat(convertedAmount);
      if (toCurrency === "eth") updatedUser.cryptoWallets.ethereum += parseFloat(convertedAmount);
      if (toCurrency === "sol") updatedUser.cryptoWallets.solana += parseFloat(convertedAmount);
      if (toCurrency === "avax") updatedUser.cryptoWallets.avax += parseFloat(convertedAmount);
      if (toCurrency === "ada") updatedUser.cryptoWallets.ada += parseFloat(convertedAmount);
      
      setUser(updatedUser);
      localStorage.setItem("user", JSON.stringify(updatedUser));
      
      toast({
        title: "Conversion successful",
        description: `You converted $${numAmount} to ${convertedAmount} ${CURRENCIES[toCurrency as keyof typeof CURRENCIES].name}`,
      });
      
      // Reset form
      setAmount("");
      setConvertedAmount("");
    } else {
      // Converting from crypto to another currency
      const cryptoKey = getCryptoKey(fromCurrency);
      if (!cryptoKey) return;
      
      if (user.cryptoWallets[cryptoKey] < numAmount) {
        toast({
          title: "Insufficient balance",
          description: `You don't have enough ${CURRENCIES[fromCurrency as keyof typeof CURRENCIES].name}`,
          variant: "destructive",
        });
        return;
      }
      
      // Update user wallets
      const updatedUser = { ...user };
      updatedUser.cryptoWallets[cryptoKey] -= numAmount;
      
      if (toCurrency === "usd") {
        updatedUser.wallet += parseFloat(convertedAmount);
      } else {
        const targetCryptoKey = getCryptoKey(toCurrency);
        if (targetCryptoKey) {
          updatedUser.cryptoWallets[targetCryptoKey] += parseFloat(convertedAmount);
        }
      }
      
      setUser(updatedUser);
      localStorage.setItem("user", JSON.stringify(updatedUser));
      
      toast({
        title: "Conversion successful",
        description: `You converted ${numAmount} ${CURRENCIES[fromCurrency as keyof typeof CURRENCIES].name} to ${convertedAmount} ${CURRENCIES[toCurrency as keyof typeof CURRENCIES].name}`,
      });
      
      // Reset form
      setAmount("");
      setConvertedAmount("");
    }
  };
  
  const getCryptoKey = (currencyCode: string): keyof UserType["cryptoWallets"] | null => {
    switch (currencyCode) {
      case "btc": return "bitcoin";
      case "eth": return "ethereum";
      case "sol": return "solana";
      case "avax": return "avax";
      case "ada": return "ada";
      default: return null;
    }
  };
  
  const getBalance = (currencyCode: string): string => {
    if (currencyCode === "usd") {
      return user.wallet.toFixed(2);
    }
    
    const cryptoKey = getCryptoKey(currencyCode);
    if (!cryptoKey) return "0";
    
    const balance = user.cryptoWallets[cryptoKey];
    return balance.toFixed(8);
  };
  
  return (
    <Card className="bg-gradient-to-br from-indigo-50 to-blue-50 border-indigo-100 dark:from-indigo-900/20 dark:to-blue-900/20 dark:border-indigo-800">
      <CardHeader>
        <CardTitle className="text-indigo-800 dark:text-indigo-300">Currency Converter</CardTitle>
        <CardDescription>Convert between different cryptocurrencies and USD</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="from-currency">From</Label>
              <Select 
                value={fromCurrency} 
                onValueChange={(value) => {
                  setFromCurrency(value);
                  setConvertedAmount("");
                }}
              >
                <SelectTrigger id="from-currency">
                  <SelectValue placeholder="Select currency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="usd">USD (Wallet)</SelectItem>
                  <SelectItem value="btc">Bitcoin</SelectItem>
                  <SelectItem value="eth">Ethereum</SelectItem>
                  <SelectItem value="sol">Solana</SelectItem>
                  <SelectItem value="avax">Avalanche</SelectItem>
                  <SelectItem value="ada">Cardano</SelectItem>
                </SelectContent>
              </Select>
              <p className="mt-1 text-xs text-gray-500">
                Available: {getBalance(fromCurrency)} {CURRENCIES[fromCurrency as keyof typeof CURRENCIES].name}
              </p>
            </div>
            <div>
              <Label htmlFor="to-currency">To</Label>
              <Select 
                value={toCurrency} 
                onValueChange={(value) => {
                  setToCurrency(value);
                  setConvertedAmount("");
                }}
              >
                <SelectTrigger id="to-currency">
                  <SelectValue placeholder="Select currency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="usd">USD (Wallet)</SelectItem>
                  <SelectItem value="btc">Bitcoin</SelectItem>
                  <SelectItem value="eth">Ethereum</SelectItem>
                  <SelectItem value="sol">Solana</SelectItem>
                  <SelectItem value="avax">Avalanche</SelectItem>
                  <SelectItem value="ada">Cardano</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div>
            <Label htmlFor="amount">Amount</Label>
            <Input 
              id="amount" 
              type="number" 
              placeholder="0.00" 
              value={amount}
              onChange={(e) => {
                setAmount(e.target.value);
                setConvertedAmount("");
              }}
              min="0"
            />
          </div>
          
          {convertedAmount && (
            <div className="p-4 bg-white dark:bg-gray-800 rounded-md">
              <div className="text-sm text-gray-500 mb-1">Converted Amount</div>
              <div className="text-xl font-bold">
                {convertedAmount} {CURRENCIES[toCurrency as keyof typeof CURRENCIES].name}
              </div>
              <div className="text-xs text-gray-500 mt-1">
                Rate: 1 {CURRENCIES[fromCurrency as keyof typeof CURRENCIES].name} = 
                {(CURRENCIES[toCurrency as keyof typeof CURRENCIES].rate / 
                  CURRENCIES[fromCurrency as keyof typeof CURRENCIES].rate).toFixed(8)} {CURRENCIES[toCurrency as keyof typeof CURRENCIES].name}
              </div>
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter className="flex flex-col sm:flex-row gap-2">
        <Button 
          variant="outline" 
          onClick={calculateConversion}
          className="w-full sm:w-auto"
        >
          Calculate
        </Button>
        <Button 
          onClick={handleConvert} 
          disabled={!convertedAmount || fromCurrency === toCurrency}
          className="w-full sm:w-auto"
        >
          Convert
        </Button>
      </CardFooter>
    </Card>
  );
}
