
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { MainLayout } from "@/components/layouts/MainLayout";

// Public pages
import Index from "./pages/Index";
import Login from "./pages/Login";
import Register from "./pages/Register";
import NotFound from "./pages/NotFound";

// Footer Pages
import About from "./pages/footerpages/About";
import Contact from "./pages/footerpages/Contact";
import Privacy from "./pages/footerpages/Privacy";
import Terms from "./pages/footerpages/Terms";
import Leaderboard from "./pages/footerpages/Leaderboard";

// User pages
import Dashboard from "./pages/Dashboard";
import Profile from "./pages/Profile";
import Settings from "./pages/Settings";
import Videos from "./pages/dashboard/Videos";
import News from "./pages/dashboard/News";
import Referrals from "./pages/dashboard/Referrals";
import Wallet from "./pages/dashboard/Wallet";
import Deposit from "./pages/dashboard/Deposit";
import Withdraw from "./pages/dashboard/Withdraw";
import Convert from "./pages/dashboard/Convert";
import Kyc from "./pages/dashboard/Kyc";
import DashboardLeaderboard from "./pages/dashboard/Leaderboard";

// Admin pages
import AdminDashboard from "./pages/AdminDashboard";
import AdminVideos from "./pages/admin/Videos";
import AdminUsers from "./pages/admin/Users";
import AdminEmails from "./pages/admin/EmailServices";
import AdminEmailConfig from "./pages/admin/EmailConfig";
import AdminKyc from "./pages/admin/Kyc";
import AdminDeposits from "./pages/admin/Deposits";
import AdminWithdrawals from "./pages/admin/Withdrawals";
import AdminAccounts from "./pages/admin/Accounts";
import AdminTasks from "./pages/admin/Tasks";
import AdminAdministrators from "./pages/admin/Administrators";
import AdminSettings from "./pages/admin/Settings";
import AdminProfile from "./pages/admin/Profile";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <BrowserRouter>
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<Index />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          
          {/* Footer Pages */}
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/terms" element={<Terms />} />
          <Route path="/leaderboard" element={<Leaderboard />} />
          
          {/* User Routes - Individual dashboard pages */}
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/dashboard/videos" element={<Videos />} />
          <Route path="/dashboard/news" element={<News />} />
          <Route path="/dashboard/referrals" element={<Referrals />} />
          <Route path="/dashboard/wallet" element={<Wallet />} />
          <Route path="/dashboard/deposit" element={<Deposit />} />
          <Route path="/dashboard/withdraw" element={<Withdraw />} />
          <Route path="/dashboard/convert" element={<Convert />} />
          <Route path="/dashboard/kyc" element={<Kyc />} />
          <Route path="/dashboard/leaderboard" element={<DashboardLeaderboard />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/settings" element={<Settings />} />
          
          {/* Admin Routes */}
          <Route path="/admin/dashboard" element={<MainLayout><AdminDashboard /></MainLayout>} />
          <Route path="/admin/videos" element={<MainLayout><AdminVideos /></MainLayout>} />
          <Route path="/admin/users" element={<MainLayout><AdminUsers /></MainLayout>} />
          <Route path="/admin/email-services" element={<MainLayout><AdminEmails /></MainLayout>} />
          <Route path="/admin/email-config" element={<MainLayout><AdminEmailConfig /></MainLayout>} />
          <Route path="/admin/kyc" element={<MainLayout><AdminKyc /></MainLayout>} />
          <Route path="/admin/deposits" element={<MainLayout><AdminDeposits /></MainLayout>} />
          <Route path="/admin/withdrawals" element={<MainLayout><AdminWithdrawals /></MainLayout>} />
          <Route path="/admin/accounts" element={<MainLayout><AdminAccounts /></MainLayout>} />
          <Route path="/admin/tasks" element={<MainLayout><AdminTasks /></MainLayout>} />
          <Route path="/admin/administrators" element={<MainLayout><AdminAdministrators /></MainLayout>} />
          <Route path="/admin/settings" element={<MainLayout><AdminSettings /></MainLayout>} />
          <Route path="/admin/profile" element={<MainLayout><AdminProfile /></MainLayout>} />
          
          {/* 404 Catch All */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
