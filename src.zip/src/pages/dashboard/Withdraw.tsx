
import { useState, useEffect } from "react";
import { toast } from "@/hooks/use-toast";
import { UserLayout } from "@/components/layouts/UserLayout";
import { useNavigate } from "react-router-dom";
import { UserType } from "../Dashboard";
import { WithdrawalForm } from "@/components/WithdrawalForm";
import { EarningsSummary } from "@/components/EarningsSummary";
import { Card } from "@/components/ui/card";

const Withdraw = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState<UserType | null>(null);
  
  useEffect(() => {
    // Load user data
    const storedUser = localStorage.getItem("user");
    if (!storedUser) {
      toast({
        title: "Authentication required",
        description: "Please login to access the dashboard",
        variant: "destructive",
      });
      navigate("/login");
      return;
    }
    
    try {
      const userData = JSON.parse(storedUser);
      setUser(userData);
    } catch (error) {
      console.error("Error parsing user data:", error);
      navigate("/login");
    }
  }, [navigate]);

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-b from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950">
        <div className="animate-pulse flex flex-col items-center p-8 rounded-lg bg-white dark:bg-gray-800 shadow-lg">
          <div className="w-12 h-12 mb-4 rounded-full bg-blue-200 dark:bg-blue-700"></div>
          <div className="h-4 w-24 bg-blue-200 dark:bg-blue-700 rounded mb-3"></div>
          <div className="h-3 w-32 bg-gray-200 dark:bg-gray-700 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <UserLayout user={user}>
      <main className="flex-1 container py-8">
        <EarningsSummary user={user} />
        
        <div className="mt-6">
          <Card className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 animate-fade-in">
            <WithdrawalForm user={user} setUser={setUser} />
          </Card>
        </div>
      </main>
    </UserLayout>
  );
};

export default Withdraw;
