
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

const AdminTasks = () => {
  return (
    <div className="container py-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">Task Management</h1>
        <Button>Create Task</Button>
      </div>
      
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>All Tasks</CardTitle>
          <div className="flex items-center space-x-2">
            <Input 
              placeholder="Search tasks..." 
              className="w-[250px]" 
            />
            <Button variant="outline">Filter</Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="text-center py-10">
            <p className="text-muted-foreground">Task management functionality will be implemented here.</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminTasks;
