
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "@/hooks/use-toast";
import { AdminVideoManager } from "@/components/AdminVideoManager";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { generateRandomVideoCode } from "@/utils/videoUtils";

const AdminVideos = () => {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newVideo, setNewVideo] = useState({
    title: "",
    thumbnail: "",
    duration: "",
    reward: "",
    code: generateRandomVideoCode(),
    videoUrl: ""
  });

  const handleAddVideo = () => {
    // Validation
    if (!newVideo.title || !newVideo.duration || !newVideo.reward) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    // Pass the new video to the AdminVideoManager component
    // In a real app, this would be handled by the AdminVideoManager's onAdd prop
    toast({
      title: "Video added",
      description: "The new video was added successfully.",
    });

    // Reset the form and close the dialog
    setNewVideo({
      title: "",
      thumbnail: "",
      duration: "",
      reward: "",
      code: generateRandomVideoCode(),
      videoUrl: ""
    });
    setIsAddDialogOpen(false);
  };

  return (
    <div className="container py-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">Video Management</h1>
        <Button onClick={() => setIsAddDialogOpen(true)}>Add New Video</Button>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Video Content Library</CardTitle>
        </CardHeader>
        <CardContent>
          <AdminVideoManager />
        </CardContent>
      </Card>

      {/* Add New Video Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle>Add New Video</DialogTitle>
            <DialogDescription>
              Enter details for the new video content
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="title" className="text-right">
                Title
              </Label>
              <Input
                id="title"
                value={newVideo.title}
                onChange={(e) => setNewVideo({ ...newVideo, title: e.target.value })}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="thumbnail" className="text-right">
                Thumbnail URL
              </Label>
              <Input
                id="thumbnail"
                value={newVideo.thumbnail}
                onChange={(e) => setNewVideo({ ...newVideo, thumbnail: e.target.value })}
                className="col-span-3"
                placeholder="https://example.com/image.jpg"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="duration" className="text-right">
                Duration
              </Label>
              <Input
                id="duration"
                value={newVideo.duration}
                onChange={(e) => setNewVideo({ ...newVideo, duration: e.target.value })}
                className="col-span-3"
                placeholder="5:30"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="reward" className="text-right">
                Reward Amount
              </Label>
              <Input
                id="reward"
                type="number"
                step="0.01"
                value={newVideo.reward}
                onChange={(e) => setNewVideo({ ...newVideo, reward: e.target.value })}
                className="col-span-3"
                placeholder="0.50"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="code" className="text-right">
                Verification Code
              </Label>
              <div className="col-span-3 flex gap-2">
                <Input
                  id="code"
                  value={newVideo.code}
                  onChange={(e) => setNewVideo({ ...newVideo, code: e.target.value.toUpperCase() })}
                />
                <Button
                  variant="secondary"
                  onClick={() => setNewVideo({ ...newVideo, code: generateRandomVideoCode() })}
                >
                  Generate
                </Button>
              </div>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="videoUrl" className="text-right">
                Video URL
              </Label>
              <Input
                id="videoUrl"
                value={newVideo.videoUrl}
                onChange={(e) => setNewVideo({ ...newVideo, videoUrl: e.target.value })}
                className="col-span-3"
                placeholder="https://example.com/video.mp4"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddVideo}>Add Video</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminVideos;
