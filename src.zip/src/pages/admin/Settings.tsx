
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/hooks/use-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const AdminSettings = () => {
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [faviconFile, setFaviconFile] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [faviconPreview, setFaviconPreview] = useState<string | null>(null);

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Invalid file type",
        description: "Please select an image file for the logo",
        variant: "destructive",
      });
      return;
    }
    
    setLogoFile(file);
    
    // Create a preview
    const reader = new FileReader();
    reader.onloadend = () => {
      setLogoPreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };
  
  const handleFaviconChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Invalid file type",
        description: "Please select an image file for the favicon",
        variant: "destructive",
      });
      return;
    }
    
    setFaviconFile(file);
    
    // Create a preview
    const reader = new FileReader();
    reader.onloadend = () => {
      setFaviconPreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };
  
  const handleSaveAppearance = () => {
    toast({
      title: "Settings saved",
      description: "Your appearance settings have been updated.",
    });
  };
  
  const handleSaveGeneral = () => {
    toast({
      title: "Settings saved",
      description: "Your general settings have been updated.",
    });
  };

  return (
    <div className="container py-6">
      <h1 className="text-3xl font-bold mb-6">Platform Settings</h1>
      
      <Tabs defaultValue="general">
        <TabsList className="mb-4">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="appearance">Appearance</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
          <TabsTrigger value="payments">Payments</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="api">API</TabsTrigger>
        </TabsList>
        
        <TabsContent value="general">
          <Card>
            <CardHeader>
              <CardTitle>General Settings</CardTitle>
              <CardDescription>Manage basic platform configuration</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="site-name">Site Name</Label>
                <Input id="site-name" placeholder="My Rewards Platform" />
              </div>
              <div>
                <Label htmlFor="site-description">Site Description</Label>
                <Textarea id="site-description" placeholder="A platform for earning rewards through watching videos and reading news" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="contact-email">Support Email</Label>
                  <Input id="contact-email" placeholder="support@example.com" />
                </div>
                <div>
                  <Label htmlFor="timezone">Default Timezone</Label>
                  <Input id="timezone" placeholder="UTC" />
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="maintenance-mode" />
                <Label htmlFor="maintenance-mode">Maintenance Mode</Label>
              </div>
              <div className="flex justify-end">
                <Button onClick={handleSaveGeneral}>Save Settings</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="appearance">
          <Card>
            <CardHeader>
              <CardTitle>Appearance Settings</CardTitle>
              <CardDescription>Customize the look and feel of your platform</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label htmlFor="logo" className="block mb-2">Site Logo</Label>
                <div className="flex items-center gap-4">
                  {logoPreview ? (
                    <img src={logoPreview} alt="Logo Preview" className="h-16 w-auto border rounded" />
                  ) : (
                    <div className="h-16 w-32 flex items-center justify-center bg-gray-100 border rounded">
                      <span className="text-sm text-gray-500">No logo</span>
                    </div>
                  )}
                  <div className="flex-1">
                    <Input id="logo" type="file" onChange={handleLogoChange} accept="image/*" />
                    <p className="text-xs text-gray-500 mt-1">
                      Recommended size: 200x50 pixels. PNG or SVG format preferred.
                    </p>
                  </div>
                </div>
              </div>
              
              <div>
                <Label htmlFor="favicon" className="block mb-2">Favicon</Label>
                <div className="flex items-center gap-4">
                  {faviconPreview ? (
                    <img src={faviconPreview} alt="Favicon Preview" className="h-8 w-8 border rounded" />
                  ) : (
                    <div className="h-8 w-8 flex items-center justify-center bg-gray-100 border rounded">
                      <span className="text-xs text-gray-500">No icon</span>
                    </div>
                  )}
                  <div className="flex-1">
                    <Input id="favicon" type="file" onChange={handleFaviconChange} accept="image/*" />
                    <p className="text-xs text-gray-500 mt-1">
                      Recommended size: 32x32 or 64x64 pixels. PNG format preferred.
                    </p>
                  </div>
                </div>
              </div>
              
              <div>
                <Label htmlFor="theme">Color Theme</Label>
                <Select defaultValue="blue">
                  <SelectTrigger id="theme">
                    <SelectValue placeholder="Select a theme" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="blue">Blue (Default)</SelectItem>
                    <SelectItem value="purple">Purple</SelectItem>
                    <SelectItem value="green">Green</SelectItem>
                    <SelectItem value="amber">Amber</SelectItem>
                    <SelectItem value="red">Red</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch id="dark-mode" />
                <Label htmlFor="dark-mode">Enable Dark Mode by Default</Label>
              </div>
              
              <div className="flex justify-end">
                <Button onClick={handleSaveAppearance}>Save Appearance</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="security">
          <Card>
            <CardHeader>
              <CardTitle>Security Settings</CardTitle>
              <CardDescription>Configure security options for your platform</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Switch id="two-factor" />
                  <div>
                    <Label htmlFor="two-factor">Two-Factor Authentication</Label>
                    <p className="text-sm text-gray-500">Require 2FA for all administrative accounts</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Switch id="kyc-required" />
                  <div>
                    <Label htmlFor="kyc-required">Require KYC for Withdrawals</Label>
                    <p className="text-sm text-gray-500">Users must complete KYC verification before withdrawing funds</p>
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="session-timeout">Admin Session Timeout (minutes)</Label>
                  <Input id="session-timeout" type="number" defaultValue="60" min="5" max="1440" />
                </div>
                
                <div>
                  <Label htmlFor="password-policy">Password Policy</Label>
                  <Select defaultValue="strong">
                    <SelectTrigger id="password-policy">
                      <SelectValue placeholder="Select policy" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="basic">Basic (8+ characters)</SelectItem>
                      <SelectItem value="medium">Medium (8+ chars, 1 uppercase, 1 number)</SelectItem>
                      <SelectItem value="strong">Strong (8+ chars, uppercase, number, special)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex justify-end">
                  <Button>Save Security Settings</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="payments">
          <Card>
            <CardHeader>
              <CardTitle>Payment Settings</CardTitle>
              <CardDescription>Configure payment gateways and options</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-10">
                <p className="text-muted-foreground">Payment settings will be implemented here.</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle>Notification Settings</CardTitle>
              <CardDescription>Configure system notifications</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-10">
                <p className="text-muted-foreground">Notification settings will be implemented here.</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="api">
          <Card>
            <CardHeader>
              <CardTitle>API Settings</CardTitle>
              <CardDescription>Manage API keys and integrations</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-10">
                <p className="text-muted-foreground">API settings will be implemented here.</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AdminSettings;
