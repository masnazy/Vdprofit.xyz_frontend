
import { Link } from "react-router-dom";

export default function Privacy() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950">
      <header className="bg-white dark:bg-gray-900 shadow-sm">
        <div className="container mx-auto px-4 py-6">
          <Link to="/" className="flex items-center">
            <img 
              src="/logo.svg" 
              alt="Logo" 
              className="h-8 w-auto mr-2"
              onError={(e) => {
                (e.target as HTMLImageElement).src = "/placeholder.svg";
              }}
            />
            <h1 className="text-xl font-bold text-gray-900 dark:text-white">Rewards Platform</h1>
          </Link>
        </div>
      </header>
      
      <main className="container mx-auto px-4 py-10">
        <div className="prose prose-blue max-w-4xl mx-auto dark:prose-invert">
          <h1 className="text-3xl font-bold mb-6">Privacy Policy</h1>
          
          <p className="text-lg mb-6">
            Last updated: May 10, 2025
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">Introduction</h2>
          <p>
            This Privacy Policy explains how our Rewards Platform ("we", "us", or "our") collects, uses, and shares your personal information when you use our website and services.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">Information We Collect</h2>
          <p>
            We collect several different types of information for various purposes to provide and improve our service to you:
          </p>
          <ul>
            <li>Personal Data: Name, email address, and payment information</li>
            <li>Usage Data: How you interact with our platform</li>
            <li>KYC Information: Identity verification documents</li>
            <li>Cryptocurrency wallet addresses</li>
          </ul>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">How We Use Your Information</h2>
          <p>
            We use the collected data for various purposes:
          </p>
          <ul>
            <li>To provide and maintain our services</li>
            <li>To notify you about changes to our services</li>
            <li>To provide customer support</li>
            <li>To detect, prevent and address technical issues</li>
            <li>To comply with legal obligations</li>
          </ul>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">Data Security</h2>
          <p>
            The security of your data is important to us, but remember that no method of transmission over the Internet, or method of electronic storage is 100% secure. While we strive to use commercially acceptable means to protect your Personal Data, we cannot guarantee its absolute security.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">Your Rights</h2>
          <p>
            You have certain rights regarding your personal data:
          </p>
          <ul>
            <li>The right to access your data</li>
            <li>The right to rectification</li>
            <li>The right to erasure</li>
            <li>The right to restrict processing</li>
            <li>The right to data portability</li>
            <li>The right to object</li>
          </ul>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">Changes to This Privacy Policy</h2>
          <p>
            We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last updated" date.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">Contact Us</h2>
          <p>
            If you have any questions about this Privacy Policy, please <Link to="/contact" className="text-blue-600 hover:underline">contact us</Link>.
          </p>
        </div>
      </main>
      
      <footer className="bg-white dark:bg-gray-900 mt-10 py-8 border-t border-gray-200 dark:border-gray-800">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap justify-center md:justify-between items-center">
            <div className="w-full md:w-auto mb-4 md:mb-0 text-center md:text-left">
              <p className="text-sm text-gray-500 dark:text-gray-400">
                © 2025 Rewards Platform. All rights reserved.
              </p>
            </div>
            <div className="flex flex-wrap justify-center gap-4">
              <Link to="/about" className="text-sm text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400">
                About Us
              </Link>
              <Link to="/contact" className="text-sm text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400">
                Contact Us
              </Link>
              <Link to="/privacy" className="text-sm text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400">
                Privacy Policy
              </Link>
              <Link to="/terms" className="text-sm text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400">
                Terms & Conditions
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
