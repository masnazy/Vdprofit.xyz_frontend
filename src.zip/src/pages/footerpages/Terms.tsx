
import { Link } from "react-router-dom";

export default function Terms() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950">
      <header className="bg-white dark:bg-gray-900 shadow-sm">
        <div className="container mx-auto px-4 py-6">
          <Link to="/" className="flex items-center">
            <img 
              src="/logo.svg" 
              alt="Logo" 
              className="h-8 w-auto mr-2"
              onError={(e) => {
                (e.target as HTMLImageElement).src = "/placeholder.svg";
              }}
            />
            <h1 className="text-xl font-bold text-gray-900 dark:text-white">Rewards Platform</h1>
          </Link>
        </div>
      </header>
      
      <main className="container mx-auto px-4 py-10">
        <div className="prose prose-blue max-w-4xl mx-auto dark:prose-invert">
          <h1 className="text-3xl font-bold mb-6">Terms and Conditions</h1>
          
          <p className="text-lg mb-6">
            Last updated: May 10, 2025
          </p>
          
          <p>
            Please read these Terms and Conditions carefully before using our Rewards Platform.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">1. Acceptance of Terms</h2>
          <p>
            By accessing or using our platform, you agree to be bound by these Terms. If you disagree with any part of the terms, you may not access the service.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">2. Description of Service</h2>
          <p>
            Our Rewards Platform provides users with the opportunity to earn rewards by watching videos, reading news articles, and referring friends. These rewards can be withdrawn or converted to various cryptocurrencies.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">3. Account Registration</h2>
          <p>
            To use certain features of our platform, you must register for an account. You agree to provide accurate and complete information during the registration process and to update such information to keep it accurate and current.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">4. KYC Requirements</h2>
          <p>
            Users may be required to complete a Know Your Customer (KYC) verification process to access certain features or withdraw funds. This process involves providing identification documents and other personal information.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">5. Rewards and Withdrawals</h2>
          <p>
            Rewards are earned by completing specific tasks on our platform. Withdrawal of rewards is subject to our withdrawal policy, including minimum withdrawal amounts and processing times. Withdrawals may require administrative approval.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">6. Prohibited Activities</h2>
          <p>
            Users are prohibited from:
          </p>
          <ul>
            <li>Using automated methods to earn rewards</li>
            <li>Creating multiple accounts</li>
            <li>Providing false information</li>
            <li>Engaging in any activity that disrupts our platform</li>
            <li>Using our platform for illegal purposes</li>
          </ul>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">7. Termination</h2>
          <p>
            We reserve the right to terminate or suspend your account at our sole discretion, without notice, for conduct that we believe violates these Terms or is harmful to other users of our platform, us, or third parties, or for any other reason.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">8. Changes to Terms</h2>
          <p>
            We reserve the right to modify these Terms at any time. We will notify users of any changes by posting the new Terms on this page and updating the "Last updated" date.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">9. Contact Us</h2>
          <p>
            If you have any questions about these Terms, please <Link to="/contact" className="text-blue-600 hover:underline">contact us</Link>.
          </p>
        </div>
      </main>
      
      <footer className="bg-white dark:bg-gray-900 mt-10 py-8 border-t border-gray-200 dark:border-gray-800">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap justify-center md:justify-between items-center">
            <div className="w-full md:w-auto mb-4 md:mb-0 text-center md:text-left">
              <p className="text-sm text-gray-500 dark:text-gray-400">
                © 2025 Rewards Platform. All rights reserved.
              </p>
            </div>
            <div className="flex flex-wrap justify-center gap-4">
              <Link to="/about" className="text-sm text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400">
                About Us
              </Link>
              <Link to="/contact" className="text-sm text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400">
                Contact Us
              </Link>
              <Link to="/privacy" className="text-sm text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400">
                Privacy Policy
              </Link>
              <Link to="/terms" className="text-sm text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400">
                Terms & Conditions
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
