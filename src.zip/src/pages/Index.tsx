
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { toast } from "@/hooks/use-toast";

const Index = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Hero Section */}
      <div className="container mx-auto px-4 py-20">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="md:w-1/2 mb-10 md:mb-0">
            <h1 className="text-5xl font-bold text-blue-900 mb-6">
              Earn Rewards for Watching, Reading & Sharing
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Get paid for watching videos, reading news, and referring friends to our platform.
              Start earning today!
            </p>
            <div className="flex flex-wrap gap-4">
              <Button 
                size="lg" 
                onClick={() => navigate("/register")}
                className="bg-blue-600 hover:bg-blue-700"
              >
                Sign Up Now
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                onClick={() => navigate("/login")}
              >
                Login
              </Button>
            </div>
          </div>
          <div className="md:w-1/2">
            <img 
              src="/placeholder.svg" 
              alt="Rewards Illustration" 
              className="w-full h-auto rounded-lg shadow-lg"
            />
          </div>
        </div>
      </div>

      {/* How It Works */}
      <div className="bg-white py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-blue-900 mb-12">How It Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-blue-50 p-6 rounded-lg text-center">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-4">1</div>
              <h3 className="text-xl font-semibold mb-3">Watch Videos</h3>
              <p className="text-gray-600">Watch entertaining videos and verify with custom codes to earn rewards.</p>
            </div>
            <div className="bg-blue-50 p-6 rounded-lg text-center">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-4">2</div>
              <h3 className="text-xl font-semibold mb-3">Read News</h3>
              <p className="text-gray-600">Stay informed by reading news articles and earn rewards for your time.</p>
            </div>
            <div className="bg-blue-50 p-6 rounded-lg text-center">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-4">3</div>
              <h3 className="text-xl font-semibold mb-3">Refer Friends</h3>
              <p className="text-gray-600">Share your unique referral link and earn 2% commission on your referrals' earnings.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Call to Action */}
      <div className="bg-blue-600 py-16 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Start Earning?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Join thousands of users who are already earning rewards on our platform.
            Sign up now and start earning today!
          </p>
          <Button 
            size="lg" 
            onClick={() => {
              navigate("/register");
              toast({
                title: "Welcome!",
                description: "Sign up to start earning rewards",
              });
            }}
            className="bg-white text-blue-600 hover:bg-gray-100"
          >
            Create Account
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Index;
