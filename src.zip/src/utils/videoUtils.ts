
export function generateRandomVideoCode(): string {
  const prefix = "WATCH";
  const randomChars = Math.random().toString(36).substring(2, 6).toUpperCase();
  return prefix + randomChars;
}
