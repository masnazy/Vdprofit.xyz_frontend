
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";

// Mock user data
const MOCK_USERS = [
  {
    id: 1,
    name: "John Doe",
    email: "john@example.com",
    registerDate: "2023-04-12",
    wallet: 35.40,
    referralCode: "REF123ABC",
    referredBy: null,
  },
  {
    id: 2,
    name: "Jane Smith",
    email: "jane@example.com",
    registerDate: "2023-04-18",
    wallet: 127.65,
    referralCode: "REF456DEF",
    referredBy: null,
  },
  {
    id: 3,
    name: "Michael Johnson",
    email: "michael@example.com",
    registerDate: "2023-04-22",
    wallet: 54.20,
    referralCode: "REF789GHI",
    referredBy: "REF123ABC",
  },
  {
    id: 4,
    name: "Emily Davis",
    email: "emily@example.com",
    registerDate: "2023-05-02",
    wallet: 18.75,
    referralCode: "REFJKL012",
    referredBy: "REF456DEF",
  },
];

export function AdminUsersList() {
  const [users, setUsers] = useState(MOCK_USERS);
  const [userDetailsDialogOpen, setUserDetailsDialogOpen] = useState(false);
  const [walletAdjustDialogOpen, setWalletAdjustDialogOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<typeof MOCK_USERS[0] | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [walletAdjustment, setWalletAdjustment] = useState("");
  
  const filteredUsers = users.filter(user => 
    user.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.referralCode.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleAdjustWallet = () => {
    if (!selectedUser) return;
    
    const adjustment = parseFloat(walletAdjustment);
    if (isNaN(adjustment)) {
      toast({
        title: "Invalid amount",
        description: "Please enter a valid number",
        variant: "destructive",
      });
      return;
    }
    
    const updatedUsers = users.map(user => {
      if (user.id === selectedUser.id) {
        return {
          ...user,
          wallet: Math.max(0, user.wallet + adjustment), // Ensure wallet doesn't go negative
        };
      }
      return user;
    });
    
    setUsers(updatedUsers);
    setWalletAdjustDialogOpen(false);
    setWalletAdjustment("");
    
    toast({
      title: "Wallet adjusted",
      description: `${selectedUser.name}'s wallet has been ${adjustment >= 0 ? 'credited' : 'debited'} with $${Math.abs(adjustment).toFixed(2)}`,
    });
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">User Management</h2>
        <div className="w-64">
          <Input 
            placeholder="Search users..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>
      
      <div className="grid grid-cols-1 gap-4">
        {filteredUsers.map(user => (
          <Card key={user.id}>
            <CardContent className="p-4">
              <div className="flex flex-col md:flex-row md:justify-between">
                <div className="flex-1">
                  <h3 className="font-medium text-lg mb-1">{user.name}</h3>
                  <p className="text-gray-500 text-sm">{user.email}</p>
                  <div className="flex flex-wrap text-xs text-gray-500 space-x-4 my-2">
                    <span>Joined: {user.registerDate}</span>
                    <span>Wallet: ${user.wallet.toFixed(2)}</span>
                    <span>Referral: {user.referralCode}</span>
                    {user.referredBy && <span>Referred by: {user.referredBy}</span>}
                  </div>
                </div>
                <div className="flex items-start space-x-2 mt-4 md:mt-0">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => {
                      setSelectedUser(user);
                      setUserDetailsDialogOpen(true);
                    }}
                  >
                    Details
                  </Button>
                  <Button 
                    size="sm"
                    onClick={() => {
                      setSelectedUser(user);
                      setWalletAdjustDialogOpen(true);
                    }}
                  >
                    Adjust Wallet
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
        
        {filteredUsers.length === 0 && (
          <Card className="p-8 text-center">
            <p className="text-gray-500">No users found matching your search criteria.</p>
          </Card>
        )}
      </div>
      
      {/* User Details Dialog */}
      <Dialog open={userDetailsDialogOpen} onOpenChange={setUserDetailsDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>User Details</DialogTitle>
          </DialogHeader>
          {selectedUser && (
            <div className="py-4">
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <Label className="text-gray-500 text-sm">Name</Label>
                  <p className="text-lg font-medium">{selectedUser.name}</p>
                </div>
                <div>
                  <Label className="text-gray-500 text-sm">Email</Label>
                  <p className="text-lg">{selectedUser.email}</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <Label className="text-gray-500 text-sm">Registration Date</Label>
                  <p>{selectedUser.registerDate}</p>
                </div>
                <div>
                  <Label className="text-gray-500 text-sm">Wallet Balance</Label>
                  <p className="text-lg font-medium text-green-600">${selectedUser.wallet.toFixed(2)}</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-500 text-sm">Referral Code</Label>
                  <p>{selectedUser.referralCode}</p>
                </div>
                <div>
                  <Label className="text-gray-500 text-sm">Referred By</Label>
                  <p>{selectedUser.referredBy || "N/A"}</p>
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button onClick={() => setUserDetailsDialogOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Wallet Adjustment Dialog */}
      <Dialog open={walletAdjustDialogOpen} onOpenChange={setWalletAdjustDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Adjust User Wallet</DialogTitle>
          </DialogHeader>
          {selectedUser && (
            <div className="py-4">
              <div className="mb-4">
                <p>
                  Current balance for <span className="font-medium">{selectedUser.name}</span>: 
                  <span className="font-bold text-green-600 ml-1">${selectedUser.wallet.toFixed(2)}</span>
                </p>
              </div>
              <div>
                <Label htmlFor="adjustment">Adjustment Amount ($)</Label>
                <Input 
                  id="adjustment" 
                  value={walletAdjustment}
                  onChange={(e) => setWalletAdjustment(e.target.value)}
                  type="number"
                  step="0.01"
                  placeholder="Enter positive value to add, negative to subtract"
                />
                <p className="text-sm text-gray-500 mt-1">
                  Enter a positive value to add funds or a negative value to subtract funds.
                </p>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setWalletAdjustDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAdjustWallet}>
              Apply Adjustment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
