
import { useLocation, NavLink } from "react-router-dom";
import {
  User,
  LayoutDashboard,
  Video,
  Users,
  Mail,
  Settings,
  FileText,
  Coins,
  Wallet,
  ListTodo,
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarSeparator,
  SidebarHeader,
  useSidebar,
} from "@/components/ui/sidebar";

export function AdminSidebar() {
  const location = useLocation();
  const { state } = useSidebar();
  const isCollapsed = state === "collapsed";

  // Navigation items grouped by categories
  const mainNavItems = [
    { icon: LayoutDashboard, label: "Dashboard", path: "/admin/dashboard" },
    { icon: Video, label: "Videos", path: "/admin/videos" },
    { icon: Users, label: "Manage Users", path: "/admin/users" },
  ];
  
  const communicationNavItems = [
    { icon: Mail, label: "Email Services", path: "/admin/email-services" },
    { icon: Settings, label: "Email Configuration", path: "/admin/email-config" },
  ];
  
  const financeNavItems = [
    { icon: FileText, label: "KYC Applications", path: "/admin/kyc" },
    { icon: Coins, label: "Manage Deposits", path: "/admin/deposits" },
    { icon: Wallet, label: "Manage Withdrawals", path: "/admin/withdrawals" },
  ];
  
  const systemNavItems = [
    { icon: Users, label: "Manage Accounts", path: "/admin/accounts" },
    { icon: ListTodo, label: "Tasks", path: "/admin/tasks" },
    { icon: User, label: "Administrators", path: "/admin/administrators" },
    { icon: Settings, label: "Settings", path: "/admin/settings" },
  ];

  // Helper function to check if a path is active
  const isActive = (path: string) => location.pathname === path;

  // Helper function to get navigation link classes
  const getLinkClass = ({ isActive }: { isActive: boolean }) => {
    return isActive
      ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium"
      : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground";
  };

  return (
    <Sidebar>
      <SidebarHeader className="border-b border-sidebar-border">
        <div className="flex items-center p-2">
          <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary">
            <span className="text-xl font-bold text-primary-foreground">A</span>
          </div>
          {!isCollapsed && (
            <div className="ml-3">
              <p className="font-medium">Admin Panel</p>
              <p className="text-xs text-muted-foreground">Manage your platform</p>
            </div>
          )}
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Main</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {mainNavItems.map((item) => (
                <SidebarMenuItem key={item.path}>
                  <SidebarMenuButton
                    asChild
                    tooltip={isCollapsed ? item.label : undefined}
                    isActive={isActive(item.path)}
                  >
                    <NavLink to={item.path} className={getLinkClass}>
                      <item.icon className="h-4 w-4" />
                      {!isCollapsed && <span>{item.label}</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
        
        <SidebarSeparator />
        
        <SidebarGroup>
          <SidebarGroupLabel>Communication</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {communicationNavItems.map((item) => (
                <SidebarMenuItem key={item.path}>
                  <SidebarMenuButton
                    asChild
                    tooltip={isCollapsed ? item.label : undefined}
                    isActive={isActive(item.path)}
                  >
                    <NavLink to={item.path} className={getLinkClass}>
                      <item.icon className="h-4 w-4" />
                      {!isCollapsed && <span>{item.label}</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
        
        <SidebarSeparator />
        
        <SidebarGroup>
          <SidebarGroupLabel>Finance</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {financeNavItems.map((item) => (
                <SidebarMenuItem key={item.path}>
                  <SidebarMenuButton
                    asChild
                    tooltip={isCollapsed ? item.label : undefined}
                    isActive={isActive(item.path)}
                  >
                    <NavLink to={item.path} className={getLinkClass}>
                      <item.icon className="h-4 w-4" />
                      {!isCollapsed && <span>{item.label}</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
        
        <SidebarSeparator />
        
        <SidebarGroup>
          <SidebarGroupLabel>System</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {systemNavItems.map((item) => (
                <SidebarMenuItem key={item.path}>
                  <SidebarMenuButton
                    asChild
                    tooltip={isCollapsed ? item.label : undefined}
                    isActive={isActive(item.path)}
                  >
                    <NavLink to={item.path} className={getLinkClass}>
                      <item.icon className="h-4 w-4" />
                      {!isCollapsed && <span>{item.label}</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
        
        <SidebarSeparator />
        
        <SidebarGroup>
          <SidebarGroupLabel>Account</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton
                  asChild
                  tooltip={isCollapsed ? "Profile" : undefined}
                  isActive={isActive("/admin/profile")}
                >
                  <NavLink to="/admin/profile" className={getLinkClass}>
                    <User className="h-4 w-4" />
                    {!isCollapsed && <span>Profile</span>}
                  </NavLink>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}
