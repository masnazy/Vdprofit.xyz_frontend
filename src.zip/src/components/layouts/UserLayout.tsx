
import { useState } from "react";
import { Toaster } from "@/components/ui/sonner";
import { UserNav } from "@/components/UserNav";
import { 
  Sheet, 
  SheetContent, 
  SheetTrigger 
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Menu } from "lucide-react";
import { Link } from "react-router-dom";
import { UserSidebar } from "@/components/UserSidebar";

interface UserLayoutProps {
  children: React.ReactNode;
  user: any;
}

export function UserLayout({ children, user }: UserLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  
  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-b from-blue-50/30 to-white dark:from-blue-950 dark:to-gray-900">
      <header className="sticky top-0 z-30 border-b bg-white/80 dark:bg-gray-900/80 backdrop-blur-md">
        <div className="container flex h-16 items-center justify-between py-4">
          <div className="flex items-center gap-4">
            <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-5 w-5" />
                  <span className="sr-only">Toggle menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-[240px] sm:w-[300px]">
                <UserSidebar user={user} className="mt-8" />
              </SheetContent>
            </Sheet>
            <Link to="/dashboard">
              <div className="flex items-center">
                <img 
                  src="/logo.svg" 
                  alt="Logo" 
                  className="h-8 w-auto mr-2" 
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = "/placeholder.svg";
                  }}
                />
                <h1 className="text-2xl font-bold text-blue-800 dark:text-blue-300">Rewards Dashboard</h1>
              </div>
            </Link>
          </div>
          <UserNav user={user} />
        </div>
      </header>
      
      <div className="flex flex-1">
        <UserSidebar user={user} className="hidden md:flex md:w-64 border-r" />
        <main className="flex-1">
          {children}
        </main>
      </div>
      
      <footer className="bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800 py-6">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap justify-center md:justify-between items-center">
            <div className="w-full md:w-auto mb-4 md:mb-0 text-center md:text-left">
              <p className="text-sm text-gray-500 dark:text-gray-400">
                © 2025 Rewards Platform. All rights reserved.
              </p>
            </div>
            <div className="flex flex-wrap justify-center gap-4">
              <Link to="/about" className="text-sm text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400">
                About Us
              </Link>
              <Link to="/contact" className="text-sm text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400">
                Contact Us
              </Link>
              <Link to="/privacy" className="text-sm text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400">
                Privacy Policy
              </Link>
              <Link to="/terms" className="text-sm text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400">
                Terms & Conditions
              </Link>
              <Link to="/leaderboard" className="text-sm text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400">
                Leaderboard
              </Link>
            </div>
          </div>
        </div>
      </footer>
      <Toaster />
    </div>
  );
}
