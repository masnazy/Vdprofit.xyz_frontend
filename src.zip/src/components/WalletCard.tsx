
import { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";

type UserType = {
  name: string;
  email: string;
  wallet: number;
  referralCode: string;
};

type WalletCardProps = {
  user: UserType;
  setUser: React.Dispatch<React.SetStateAction<UserType | null>>;
};

export function WalletCard({ user, setUser }: WalletCardProps) {
  const [isTransferDialogOpen, setIsTransferDialogOpen] = useState(false);
  const [recipientEmail, setRecipientEmail] = useState("");
  const [transferAmount, setTransferAmount] = useState("");

  const handleTransfer = () => {
    // Validation
    if (!recipientEmail || !transferAmount) {
      toast({
        title: "Missing information",
        description: "Please enter recipient email and amount",
        variant: "destructive",
      });
      return;
    }

    const amount = parseFloat(transferAmount);
    if (isNaN(amount) || amount <= 0) {
      toast({
        title: "Invalid amount",
        description: "Please enter a valid positive number",
        variant: "destructive",
      });
      return;
    }

    if (amount > user.wallet) {
      toast({
        title: "Insufficient funds",
        description: "You don't have enough balance for this transfer",
        variant: "destructive",
      });
      return;
    }

    // In a real app, this would be an API call to transfer funds
    // For demo, we'll just update the current user's wallet
    const updatedUser = {
      ...user,
      wallet: user.wallet - amount,
    };
    setUser(updatedUser);
    localStorage.setItem("user", JSON.stringify(updatedUser));

    toast({
      title: "Transfer successful",
      description: `$${amount.toFixed(2)} has been sent to ${recipientEmail}`,
    });

    setIsTransferDialogOpen(false);
    setRecipientEmail("");
    setTransferAmount("");
  };

  return (
    <>
      <Card>
        <CardHeader className="pb-2">
          <CardTitle>Wallet Balance</CardTitle>
          <CardDescription>Your current rewards balance</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold">${user.wallet.toFixed(2)}</div>
          <p className="text-xs text-muted-foreground mt-1">
            Updated just now
          </p>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline">Withdraw</Button>
          <Button onClick={() => setIsTransferDialogOpen(true)}>Transfer</Button>
        </CardFooter>
      </Card>

      <Dialog open={isTransferDialogOpen} onOpenChange={setIsTransferDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Transfer Funds</DialogTitle>
            <DialogDescription>
              Send funds from your wallet to another user's wallet.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div>
              <Label htmlFor="recipient">Recipient Email</Label>
              <Input 
                id="recipient" 
                value={recipientEmail}
                onChange={(e) => setRecipientEmail(e.target.value)}
                placeholder="user@example.com"
              />
            </div>
            <div>
              <Label htmlFor="amount">Amount (USD)</Label>
              <Input 
                id="amount" 
                value={transferAmount}
                onChange={(e) => setTransferAmount(e.target.value)}
                placeholder="0.00"
                type="number"
                min="0.01"
                step="0.01"
              />
              <p className="text-xs text-muted-foreground mt-1">
                Available balance: ${user.wallet.toFixed(2)}
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsTransferDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleTransfer}>
              Transfer Funds
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
