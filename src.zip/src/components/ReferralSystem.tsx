
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "@/hooks/use-toast";

type UserType = {
  name: string;
  email: string;
  wallet: number;
  referralCode: string;
  referredBy?: string;
};

type ReferralSystemProps = {
  user: UserType;
};

// Mock referral data
const MOCK_REFERRALS = [
  {
    id: 1,
    name: "John Smith",
    email: "john@example.com",
    joinDate: "2023-04-28",
    earned: 45.20,
    commission: 0.90,
  },
  {
    id: 2,
    name: "Sarah Johnson",
    email: "sarah@example.com",
    joinDate: "2023-05-02",
    earned: 28.75,
    commission: 0.58,
  },
];

export function ReferralSystem({ user }: ReferralSystemProps) {
  const [copied, setCopied] = useState(false);
  const referralUrl = `${window.location.origin}/register?ref=${user.referralCode}`;

  const copyReferralLink = () => {
    navigator.clipboard.writeText(referralUrl);
    setCopied(true);
    
    toast({
      title: "Referral link copied!",
      description: "Share this link with your friends to earn commission.",
    });
    
    setTimeout(() => setCopied(false), 3000);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="pb-4">
          <CardTitle>Your Referral Link</CardTitle>
          <CardDescription>
            Share this link with friends. When they sign up and earn rewards, you'll earn a 2% commission on their earnings.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex space-x-2">
            <Input readOnly value={referralUrl} />
            <Button onClick={copyReferralLink}>
              {copied ? "Copied!" : "Copy"}
            </Button>
          </div>
          <div className="mt-4 flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">Your Referral Code:</p>
              <p className="text-lg font-bold">{user.referralCode}</p>
            </div>
            <div>
              <p className="text-sm font-medium">Commission Rate:</p>
              <p className="text-lg font-bold text-green-600">2%</p>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <div>
        <h3 className="text-lg font-medium mb-4">Your Referrals</h3>
        {MOCK_REFERRALS.length > 0 ? (
          <div className="space-y-4">
            <div className="grid grid-cols-4 font-medium text-sm text-gray-500 pb-2 border-b">
              <div>User</div>
              <div>Join Date</div>
              <div>Total Earned</div>
              <div>Your Commission</div>
            </div>
            {MOCK_REFERRALS.map(referral => (
              <div key={referral.id} className="grid grid-cols-4 text-sm items-center">
                <div>
                  <p className="font-medium">{referral.name}</p>
                  <p className="text-gray-500">{referral.email}</p>
                </div>
                <div>{referral.joinDate}</div>
                <div>${referral.earned.toFixed(2)}</div>
                <div>${referral.commission.toFixed(2)}</div>
              </div>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="py-8 text-center">
              <p className="text-gray-500 mb-4">You don't have any referrals yet.</p>
              <Button onClick={copyReferralLink}>Copy Referral Link</Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
