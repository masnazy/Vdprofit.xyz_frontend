import { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Bitcoin, Wallet, CircleDollarSign } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { UserType } from "@/pages/Dashboard";

type WithdrawalFormProps = {
  user: UserType;
  setUser: React.Dispatch<React.SetStateAction<UserType | null>>;
};

export function WithdrawalForm({ user, setUser }: WithdrawalFormProps) {
  const [withdrawMethod, setWithdrawMethod] = useState<string>("bitcoin");
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [walletAddress, setWalletAddress] = useState("");
  const [confirmDialogOpen, setConfirmDialogOpen] = useState(false);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const amount = parseFloat(withdrawAmount);
    
    // Validation
    if (isNaN(amount) || amount <= 0) {
      toast({
        title: "Invalid amount",
        description: "Please enter a valid positive number",
        variant: "destructive",
      });
      return;
    }
    
    if (!walletAddress) {
      toast({
        title: "Missing wallet address",
        description: "Please enter your wallet address",
        variant: "destructive",
      });
      return;
    }
    
    // Check if user is withdrawing USD or crypto
    const sufficientFunds = withdrawMethod === "usd" 
      ? user.wallet >= amount
      : user.cryptoWallets[withdrawMethod as keyof typeof user.cryptoWallets] >= amount;
    
    if (!sufficientFunds) {
      toast({
        title: "Insufficient funds",
        description: `You don't have enough ${withdrawMethod.toUpperCase()} for this withdrawal`,
        variant: "destructive",
      });
      return;
    }
    
    // Open confirmation dialog
    setConfirmDialogOpen(true);
  };
  
  const confirmWithdrawal = () => {
    const amount = parseFloat(withdrawAmount);
    const updatedUser = { ...user };
    
    // Process the withdrawal based on method
    if (withdrawMethod === "usd") {
      updatedUser.wallet -= amount;
    } else {
      updatedUser.cryptoWallets[withdrawMethod as keyof typeof updatedUser.cryptoWallets] -= amount;
    }
    
    // Track total withdrawals in USD (simplified conversion)
    if (withdrawMethod === "usd") {
      updatedUser.totalWithdrawal += amount;
    } else {
      // Simple conversion rates for demo
      const rates = {
        bitcoin: 27500,
        ethereum: 1600,
        solana: 19.5,
        avax: 11.5,
        ada: 0.38
      };
      updatedUser.totalWithdrawal += amount * rates[withdrawMethod as keyof typeof rates];
    }
    
    setUser(updatedUser);
    localStorage.setItem("user", JSON.stringify(updatedUser));
    
    toast({
      title: "Withdrawal initiated",
      description: `Your withdrawal of ${amount} ${withdrawMethod.toUpperCase()} has been submitted`,
    });
    
    // Close dialog and reset form
    setConfirmDialogOpen(false);
    setWithdrawAmount("");
    setWalletAddress("");
  };
  
  const getAvailableBalance = () => {
    if (withdrawMethod === "usd") {
      return user.wallet;
    }
    return user.cryptoWallets[withdrawMethod as keyof typeof user.cryptoWallets];
  };

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Withdraw Funds</CardTitle>
          <CardDescription>Transfer your earnings to your personal wallet</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="withdrawMethod">Withdrawal Method</Label>
              <Select 
                value={withdrawMethod} 
                onValueChange={setWithdrawMethod}
              >
                <SelectTrigger id="withdrawMethod" className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="usd">USD (Available Balance)</SelectItem>
                  <SelectItem value="bitcoin">Bitcoin (BTC)</SelectItem>
                  <SelectItem value="ethereum">Ethereum (ETH)</SelectItem>
                  <SelectItem value="solana">Solana (SOL)</SelectItem>
                  <SelectItem value="avax">Avalanche (AVAX)</SelectItem>
                  <SelectItem value="ada">Cardano (ADA)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="amount">Amount</Label>
              <div className="flex items-center mt-1">
                <Input
                  id="amount"
                  value={withdrawAmount}
                  onChange={(e) => setWithdrawAmount(e.target.value)}
                  type="number"
                  min="0"
                  step="any"
                  className="flex-1"
                />
                <Button 
                  type="button"
                  variant="outline" 
                  className="ml-2"
                  onClick={() => setWithdrawAmount(getAvailableBalance().toString())}
                >
                  Max
                </Button>
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Available: {getAvailableBalance().toFixed(withdrawMethod === "usd" ? 2 : 8)} {withdrawMethod.toUpperCase()}
              </p>
            </div>
            
            <div>
              <Label htmlFor="walletAddress">Wallet Address</Label>
              <Input
                id="walletAddress"
                value={walletAddress}
                onChange={(e) => setWalletAddress(e.target.value)}
                placeholder={`Enter your ${withdrawMethod} wallet address`}
                className="mt-1"
              />
            </div>
            
            <div className="bg-muted p-4 rounded-md text-sm">
              <p className="font-medium mb-1">Withdrawal Information</p>
              <ul className="text-xs text-muted-foreground space-y-1">
                <li>• Minimum withdrawal: 0.001 BTC / 0.01 ETH / 0.5 SOL / $10 USD</li>
                <li>• Processing time: 24-48 hours</li>
                <li>• Please double-check your wallet address before submitting</li>
              </ul>
            </div>
          </form>
        </CardContent>
        <CardFooter>
          <Button 
            onClick={handleSubmit}
            disabled={!withdrawAmount || !walletAddress || isNaN(parseFloat(withdrawAmount)) || parseFloat(withdrawAmount) <= 0}
            className="w-full"
          >
            Submit Withdrawal
          </Button>
        </CardFooter>
      </Card>
      
      <Dialog open={confirmDialogOpen} onOpenChange={setConfirmDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Withdrawal</DialogTitle>
            <DialogDescription>
              Please review your withdrawal details
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <div className="grid grid-cols-2 gap-2">
              <div className="text-sm">Amount:</div>
              <div className="text-sm font-medium">
                {parseFloat(withdrawAmount).toFixed(withdrawMethod === "usd" ? 2 : 8)} {withdrawMethod.toUpperCase()}
              </div>
              
              <div className="text-sm">Method:</div>
              <div className="text-sm font-medium capitalize">
                {withdrawMethod}
              </div>
              
              <div className="text-sm">Address:</div>
              <div className="text-sm font-medium font-mono text-xs truncate">
                {walletAddress}
              </div>
            </div>
            
            <div className="bg-amber-50 p-3 rounded-md border border-amber-200">
              <p className="text-xs text-amber-800">
                Warning: Please verify that the address is correct. Withdrawals cannot be reversed once processed.
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfirmDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={confirmWithdrawal}>
              Confirm Withdrawal
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
