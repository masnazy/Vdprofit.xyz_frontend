
import { Card, CardContent } from "@/components/ui/card";
import { UserType } from "@/pages/Dashboard";
import { ArrowUpRight, Clock, CheckCircle2, AlertCircle } from "lucide-react";

type EarningsSummaryProps = {
  user: UserType;
};

export function EarningsSummary({ user }: EarningsSummaryProps) {
  const safeNumber = (value: any): number => {
    if (value === undefined || value === null) return 0;
    const num = Number(value);
    return isNaN(num) ? 0 : num;
  };

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-6">
      <Card className="bg-gradient-to-br from-violet-50 to-purple-50 border-purple-100 dark:from-violet-900/20 dark:to-purple-900/20 dark:border-purple-800">
        <CardContent className="p-6">
          <div className="flex items-center justify-between space-x-2">
            <div className="flex items-center space-x-2">
              <span className="text-2xl font-bold">${safeNumber(user.wallet).toFixed(2)}</span>
            </div>
            <div className="rounded-full p-2 bg-violet-100 dark:bg-violet-800">
              <Wallet className="h-4 w-4 text-violet-600 dark:text-violet-300" />
            </div>
          </div>
          <div className="text-xs text-gray-500 dark:text-gray-400">Account Balance</div>
          <div className="mt-3 flex items-center text-xs text-green-600 dark:text-green-400">
            <ArrowUpRight className="mr-1 h-3 w-3" />
            <span>Available for withdrawal</span>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 border-blue-100 dark:from-blue-900/20 dark:to-cyan-900/20 dark:border-blue-800">
        <CardContent className="p-6">
          <div className="flex items-center justify-between space-x-2">
            <div className="flex items-center space-x-2">
              <span className="text-2xl font-bold">{safeNumber(user.tasksCompleted)}</span>
            </div>
            <div className="rounded-full p-2 bg-blue-100 dark:bg-blue-800">
              <CheckCircle2 className="h-4 w-4 text-blue-600 dark:text-blue-300" />
            </div>
          </div>
          <div className="text-xs text-gray-500 dark:text-gray-400">Tasks Completed</div>
          <div className="mt-3 flex items-center text-xs text-blue-600 dark:text-blue-400">
            <span>Videos and other activities</span>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-amber-50 to-yellow-50 border-amber-100 dark:from-amber-900/20 dark:to-yellow-900/20 dark:border-amber-800">
        <CardContent className="p-6">
          <div className="flex items-center justify-between space-x-2">
            <div className="flex items-center space-x-2">
              <span className="text-2xl font-bold">{safeNumber(user.pendingDeposits) || 0}</span>
            </div>
            <div className="rounded-full p-2 bg-amber-100 dark:bg-amber-800">
              <Clock className="h-4 w-4 text-amber-600 dark:text-amber-300" />
            </div>
          </div>
          <div className="text-xs text-gray-500 dark:text-gray-400">Pending Deposits</div>
          <div className="mt-3 flex items-center text-xs text-amber-600 dark:text-amber-400">
            <span>Awaiting approval</span>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-orange-50 to-red-50 border-orange-100 dark:from-orange-900/20 dark:to-red-900/20 dark:border-orange-800">
        <CardContent className="p-6">
          <div className="flex items-center justify-between space-x-2">
            <div className="flex items-center space-x-2">
              <span className="text-2xl font-bold">{safeNumber(user.pendingWithdrawals) || 0}</span>
            </div>
            <div className="rounded-full p-2 bg-orange-100 dark:bg-orange-800">
              <AlertCircle className="h-4 w-4 text-orange-600 dark:text-orange-300" />
            </div>
          </div>
          <div className="text-xs text-gray-500 dark:text-gray-400">Pending Withdrawals</div>
          <div className="mt-3 flex items-center text-xs text-orange-600 dark:text-orange-400">
            <span>Processing requests</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function Wallet(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <path d="M20 12V8H6a2 2 0 0 1-2-2c0-1.1.9-2 2-2h12v4" />
      <path d="M4 6v12c0 1.1.9 2 2 2h14v-4" />
      <path d="M18 12a2 2 0 0 0 0 4h4v-4Z" />
    </svg>
  );
}
