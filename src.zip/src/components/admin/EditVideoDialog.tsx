
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Video } from "@/types/video";

interface EditVideoDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: () => void;
  selectedVideo: Video | null;
  setSelectedVideo: (video: Video | null) => void;
  generateRandomCode: () => string;
}

export function EditVideoDialog({ 
  open, 
  onOpenChange, 
  onSave, 
  selectedVideo, 
  setSelectedVideo,
  generateRandomCode
}: EditVideoDialogProps) {
  if (!selectedVideo) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Edit Video</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div>
            <Label htmlFor="edit-title">Title</Label>
            <Input 
              id="edit-title" 
              value={selectedVideo.title}
              onChange={(e) => setSelectedVideo({...selectedVideo, title: e.target.value})}
            />
          </div>
          <div>
            <Label htmlFor="edit-videoUrl">Video URL</Label>
            <Input 
              id="edit-videoUrl" 
              value={selectedVideo.videoUrl}
              onChange={(e) => setSelectedVideo({...selectedVideo, videoUrl: e.target.value})}
            />
          </div>
          <div>
            <Label htmlFor="edit-thumbnail">Thumbnail URL</Label>
            <Input 
              id="edit-thumbnail" 
              value={selectedVideo.thumbnail}
              onChange={(e) => setSelectedVideo({...selectedVideo, thumbnail: e.target.value})}
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="edit-duration">Duration (mm:ss)</Label>
              <Input 
                id="edit-duration" 
                value={selectedVideo.duration}
                onChange={(e) => setSelectedVideo({...selectedVideo, duration: e.target.value})}
              />
            </div>
            <div>
              <Label htmlFor="edit-reward">Reward Amount ($)</Label>
              <Input 
                id="edit-reward" 
                value={selectedVideo.reward}
                onChange={(e) => setSelectedVideo({...selectedVideo, reward: parseFloat(e.target.value) || selectedVideo.reward})}
                type="number"
                step="0.01"
                min="0"
              />
            </div>
          </div>
          <div className="flex gap-4 items-end">
            <div className="flex-1">
              <Label htmlFor="edit-code">Verification Code</Label>
              <Input 
                id="edit-code" 
                value={selectedVideo.code}
                onChange={(e) => setSelectedVideo({...selectedVideo, code: e.target.value.toUpperCase()})}
              />
              <p className="text-xs text-muted-foreground mt-1">
                This is the code users will enter to verify they watched the video
              </p>
            </div>
            <Button 
              variant="outline"
              onClick={() => setSelectedVideo({...selectedVideo, code: generateRandomCode()})}
            >
              Generate
            </Button>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={onSave}>
            Save Changes
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
