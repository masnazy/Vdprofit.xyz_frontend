
import { Link, NavLink, useLocation } from "react-router-dom";
import { 
  Video, 
  FileText, 
  Users, 
  ArrowDownCircle, 
  RefreshCw,
  ArrowUpCircle, 
  Wallet, 
  Layout,
  Home,
  Upload
} from "lucide-react";
import { cn } from "@/lib/utils";
import { UserType } from "@/pages/Dashboard";

interface UserSidebarProps {
  className?: string;
  user: UserType;
}

export function UserSidebar({ className, user }: UserSidebarProps) {
  const location = useLocation();
  
  const menuItems = [
    { icon: Home, label: 'Dashboard', path: '/dashboard' },
    { icon: Video, label: 'Videos', path: '/dashboard/videos' },
    { icon: FileText, label: 'News', path: '/dashboard/news' },
    { icon: Users, label: 'Referrals', path: '/dashboard/referrals' },
    { icon: Wallet, label: 'Wallet', path: '/dashboard/wallet' },
    { icon: ArrowDownCircle, label: 'Deposit', path: '/dashboard/deposit' },
    { icon: ArrowUpCircle, label: 'Withdraw', path: '/dashboard/withdraw' },
    { icon: RefreshCw, label: 'Convert', path: '/dashboard/convert' },
    { icon: Upload, label: 'KYC', path: '/dashboard/kyc' },
    { icon: Layout, label: 'Leaderboard', path: '/dashboard/leaderboard' }
  ];
  
  return (
    <div className={cn("flex flex-col h-full bg-white dark:bg-gray-900", className)}>
      <div className="space-y-4 py-4">
        <div className="px-4 py-2">
          <h2 className="mb-2 px-2 text-lg font-semibold tracking-tight">
            Menu
          </h2>
          <div className="space-y-1">
            {menuItems.map((item) => (
              <NavLink 
                key={item.path} 
                to={item.path}
                className={({ isActive }) => cn(
                  "flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors",
                  isActive 
                    ? "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200" 
                    : "hover:bg-blue-50 dark:hover:bg-blue-900/50"
                )}
              >
                <item.icon className="h-4 w-4" />
                {item.label}
              </NavLink>
            ))}
          </div>
        </div>
        
        <div className="px-4 py-2">
          <h2 className="mb-2 px-2 text-lg font-semibold tracking-tight">
            Status
          </h2>
          <div className="px-2">
            <div className="mb-2">
              <div className="text-sm font-medium">Account Type</div>
              <div className={cn(
                "text-sm rounded-full px-2 py-0.5 inline-block",
                user.isPremium ? "bg-amber-100 text-amber-800" : "bg-blue-100 text-blue-800"
              )}>
                {user.isPremium ? "Premium" : "Standard"}
              </div>
            </div>
            <div className="mb-2">
              <div className="text-sm font-medium">Pending Deposits</div>
              <div className="text-sm text-orange-600">
                {user.pendingDeposits || 0} deposits
              </div>
            </div>
            <div>
              <div className="text-sm font-medium">Pending Withdrawals</div>
              <div className="text-sm text-orange-600">
                {user.pendingWithdrawals || 0} withdrawals
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
