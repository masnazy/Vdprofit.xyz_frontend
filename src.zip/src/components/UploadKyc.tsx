
import { useState } from "react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";
import { UserType } from "@/pages/Dashboard";
import { Badge } from "@/components/ui/badge";

type UploadKycProps = {
  user: UserType;
  setUser: React.Dispatch<React.SetStateAction<UserType | null>>;
};

export function UploadKyc({ user, setUser }: UploadKycProps) {
  const [documentType, setDocumentType] = useState("");
  const [documentFront, setDocumentFront] = useState<File | null>(null);
  const [documentBack, setDocumentBack] = useState<File | null>(null);
  const [selfieWithDocument, setSelfieWithDocument] = useState<File | null>(null);
  const [additionalInfo, setAdditionalInfo] = useState("");
  const [kycStatus, setKycStatus] = useState(user.kycStatus || "not_submitted");
  
  const handleDocumentFrontChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setDocumentFront(e.target.files[0]);
    }
  };
  
  const handleDocumentBackChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setDocumentBack(e.target.files[0]);
    }
  };
  
  const handleSelfieChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelfieWithDocument(e.target.files[0]);
    }
  };
  
  const handleSubmit = () => {
    if (!documentType || !documentFront || !selfieWithDocument) {
      toast({
        title: "Missing information",
        description: "Please fill all required fields and upload required documents.",
        variant: "destructive",
      });
      return;
    }
    
    // In a real app, you'd upload these files to a server
    // For this demo, we'll simulate the process
    
    // Update user's KYC status - fix type issues
    const updatedUser = {
      ...user,
      kycStatus: "pending" as "not_submitted" | "pending" | "approved" | "rejected",
      kycSubmittedAt: new Date().toISOString(),
    };
    
    setUser(updatedUser);
    localStorage.setItem("user", JSON.stringify(updatedUser));
    setKycStatus("pending");
    
    toast({
      title: "KYC application submitted",
      description: "Your KYC application has been submitted for review.",
    });
    
    // Reset form
    setDocumentType("");
    setDocumentFront(null);
    setDocumentBack(null);
    setSelfieWithDocument(null);
    setAdditionalInfo("");
  };
  
  const renderStatusBadge = () => {
    switch (kycStatus) {
      case "approved":
        return <Badge className="bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100">Approved</Badge>;
      case "pending":
        return <Badge className="bg-amber-100 text-amber-800 dark:bg-amber-800 dark:text-amber-100">Pending Review</Badge>;
      case "rejected":
        return <Badge variant="destructive">Rejected</Badge>;
      default:
        return <Badge variant="outline">Not Submitted</Badge>;
    }
  };
  
  return (
    <Card className="bg-gradient-to-br from-rose-50 to-pink-50 border-rose-100 dark:from-rose-900/20 dark:to-pink-900/20 dark:border-rose-800">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="text-rose-800 dark:text-rose-300">KYC Verification</CardTitle>
          <CardDescription>Complete your identity verification</CardDescription>
        </div>
        {renderStatusBadge()}
      </CardHeader>
      <CardContent>
        {kycStatus === "pending" ? (
          <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-md p-4">
            <h3 className="font-medium text-amber-800 dark:text-amber-300">Your KYC application is under review</h3>
            <p className="text-sm text-amber-700 dark:text-amber-400 mt-1">
              We're currently reviewing your submitted documents. This process typically takes 1-2 business days.
            </p>
          </div>
        ) : kycStatus === "approved" ? (
          <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-md p-4">
            <h3 className="font-medium text-green-800 dark:text-green-300">Your KYC is verified</h3>
            <p className="text-sm text-green-700 dark:text-green-400 mt-1">
              Your identity has been successfully verified. You now have access to all platform features.
            </p>
          </div>
        ) : kycStatus === "rejected" ? (
          <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-md p-4 mb-4">
            <h3 className="font-medium text-red-800 dark:text-red-300">Your KYC application was rejected</h3>
            <p className="text-sm text-red-700 dark:text-red-400 mt-1">
              Please review the feedback below and submit a new application with the corrected information.
            </p>
            <p className="text-sm font-medium mt-2">Reason:</p>
            <p className="text-sm mt-1">The uploaded documents were unclear. Please upload clearer images.</p>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="grid grid-cols-1 gap-4">
              <div>
                <Label htmlFor="document-type">Document Type</Label>
                <Select value={documentType} onValueChange={setDocumentType}>
                  <SelectTrigger id="document-type">
                    <SelectValue placeholder="Select ID type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="passport">Passport</SelectItem>
                    <SelectItem value="national_id">National ID</SelectItem>
                    <SelectItem value="drivers_license">Driver's License</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="document-front">Document Front Side (Required)</Label>
                <Input
                  id="document-front"
                  type="file"
                  onChange={handleDocumentFrontChange}
                  accept="image/*"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Upload a clear image of the front of your document
                </p>
              </div>
              
              <div>
                <Label htmlFor="document-back">Document Back Side</Label>
                <Input
                  id="document-back"
                  type="file"
                  onChange={handleDocumentBackChange}
                  accept="image/*"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Upload a clear image of the back of your document (if applicable)
                </p>
              </div>
              
              <div>
                <Label htmlFor="selfie">Selfie with Document (Required)</Label>
                <Input
                  id="selfie"
                  type="file"
                  onChange={handleSelfieChange}
                  accept="image/*"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Upload a selfie of yourself holding your ID document
                </p>
              </div>
              
              <div>
                <Label htmlFor="additional-info">Additional Information (Optional)</Label>
                <Textarea
                  id="additional-info"
                  placeholder="Any additional information you'd like to provide"
                  value={additionalInfo}
                  onChange={(e) => setAdditionalInfo(e.target.value)}
                />
              </div>
            </div>
          </div>
        )}
      </CardContent>
      {kycStatus !== "approved" && kycStatus !== "pending" && (
        <CardFooter>
          <Button onClick={handleSubmit} className="w-full">
            Submit KYC Application
          </Button>
        </CardFooter>
      )}
    </Card>
  );
}
